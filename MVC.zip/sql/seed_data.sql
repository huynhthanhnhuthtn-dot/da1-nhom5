-- Insert admin account
INSERT INTO `nguoi_dung` (`ho_ten`, `email`, `so_dien_thoai`, `ten_user`, `mat_khau`, `trang_thai`, `vai_tro`)
VALUES ('Admin', 'admin@nhathuoc5.vn', '0901234567', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active', 'admin');
-- Password: password

-- Insert sample categories
INSERT INTO `danh_muc_san_pham` (`ten_danh_muc`) VALUES
('Thực phẩm chức năng'),
('Chăm sóc cá nhân'),
('Dược mỹ phẩm'),
('Thiết bị y tế'),
('Sinh lý nội tiết'),
('Sức khỏe tim mạch'),
('Hỗ trợ tiêu hóa'),
('Thần kinh não'),
('Hỗ trợ điều trị'),
('Thảo dược và thực phẩm');

-- Insert sample brands
INSERT INTO `thuong_hieu` (`ten_thuong_hieu`) VALUES
('Nhà thuốc 5'),
('Dược Hậu Giang'),
('Sanofi'),
('GSK'),
('Traphaco');
