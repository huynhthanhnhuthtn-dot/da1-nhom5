<?php
$router->get('/admin', ['Admin\\DashboardController', 'index']);

$router->get('/admin/san-pham', ['Admin\\ProductController', 'index']);
$router->get('/admin/san-pham/them', ['Admin\\ProductController', 'create']);
$router->post('/admin/san-pham/them', ['Admin\\ProductController', 'store']);
$router->get('/admin/san-pham/sua/{id}', ['Admin\\ProductController', 'edit']);
$router->post('/admin/san-pham/sua/{id}', ['Admin\\ProductController', 'update']);
$router->post('/admin/san-pham/xoa/{id}', ['Admin\\ProductController', 'delete']);

$router->get('/admin/danh-muc', ['Admin\\CategoryController', 'index']);
$router->get('/admin/danh-muc/them', ['Admin\\CategoryController', 'create']);
$router->post('/admin/danh-muc/them', ['Admin\\CategoryController', 'store']);
$router->get('/admin/danh-muc/sua/{id}', ['Admin\\CategoryController', 'edit']);
$router->post('/admin/danh-muc/sua/{id}', ['Admin\\CategoryController', 'update']);
$router->post('/admin/danh-muc/xoa/{id}', ['Admin\\CategoryController', 'delete']);

$router->get('/admin/thuong-hieu', ['Admin\\BrandController', 'index']);
$router->get('/admin/thuong-hieu/them', ['Admin\\BrandController', 'create']);
$router->post('/admin/thuong-hieu/them', ['Admin\\BrandController', 'store']);
$router->get('/admin/thuong-hieu/sua/{id}', ['Admin\\BrandController', 'edit']);
$router->post('/admin/thuong-hieu/sua/{id}', ['Admin\\BrandController', 'update']);
$router->post('/admin/thuong-hieu/xoa/{id}', ['Admin\\BrandController', 'delete']);

$router->get('/admin/don-hang', ['Admin\\OrderController', 'index']);
$router->get('/admin/don-hang/{id}', ['Admin\\OrderController', 'detail']);
$router->post('/admin/don-hang/cap-nhat-trang-thai', ['Admin\\OrderController', 'updateStatus']);

$router->get('/admin/nguoi-dung', ['Admin\\UserController', 'index']);
$router->get('/admin/nguoi-dung/sua/{id}', ['Admin\\UserController', 'edit']);
$router->post('/admin/nguoi-dung/sua/{id}', ['Admin\\UserController', 'update']);

$router->get('/admin/tin-tuc', ['Admin\\BlogController', 'index']);
$router->get('/admin/tin-tuc/them', ['Admin\\BlogController', 'create']);
$router->post('/admin/tin-tuc/them', ['Admin\\BlogController', 'store']);
$router->get('/admin/tin-tuc/sua/{id}', ['Admin\\BlogController', 'edit']);
$router->post('/admin/tin-tuc/sua/{id}', ['Admin\\BlogController', 'update']);
$router->post('/admin/tin-tuc/xoa/{id}', ['Admin\\BlogController', 'delete']);

$router->get('/admin/khuyen-mai', ['Admin\\CouponController', 'index']);
$router->get('/admin/khuyen-mai/them', ['Admin\\CouponController', 'create']);
$router->post('/admin/khuyen-mai/them', ['Admin\\CouponController', 'store']);
$router->get('/admin/khuyen-mai/sua/{id}', ['Admin\\CouponController', 'edit']);
$router->post('/admin/khuyen-mai/sua/{id}', ['Admin\\CouponController', 'update']);
$router->post('/admin/khuyen-mai/xoa/{id}', ['Admin\\CouponController', 'delete']);

$router->get('/admin/yeu-cau-ke-toa', ['Admin\\PrescriptionController', 'index']);
$router->get('/admin/yeu-cau-ke-toa/{id}', ['Admin\\PrescriptionController', 'detail']);
$router->post('/admin/yeu-cau-ke-toa/cap-nhat', ['Admin\\PrescriptionController', 'updateStatus']);

$router->get('/admin/danh-muc-tin', ['Admin\\BlogCategoryController', 'index']);
$router->post('/admin/danh-muc-tin/them', ['Admin\\BlogCategoryController', 'store']);
$router->post('/admin/danh-muc-tin/sua', ['Admin\\BlogCategoryController', 'update']);
$router->post('/admin/danh-muc-tin/xoa/{id}', ['Admin\\BlogCategoryController', 'delete']);

$router->get('/admin/dang-nhap', ['Admin\\AuthController', 'loginForm']);
$router->post('/admin/dang-nhap', ['Admin\\AuthController', 'login']);
$router->get('/admin/dang-xuat', ['Admin\\AuthController', 'logout']);
