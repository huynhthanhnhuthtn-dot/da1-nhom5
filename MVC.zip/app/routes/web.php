<?php
$router->get('/', ['Website\\HomeController', 'index']);

$router->get('/san-pham', ['Website\\ProductController', 'index']);
$router->get('/san-pham/{id}', ['Website\\ProductController', 'detail']);
$router->get('/danh-muc/{slug}', ['Website\\ProductController', 'category']);

$router->get('/gio-hang', ['Website\\CartController', 'index']);
$router->post('/gio-hang/them', ['Website\\CartController', 'add']);
$router->post('/gio-hang/cap-nhat', ['Website\\CartController', 'update']);
$router->post('/gio-hang/xoa', ['Website\\CartController', 'remove']);

$router->get('/thanh-toan', ['Website\\CheckoutController', 'index']);
$router->post('/thanh-toan/dat-hang', ['Website\\CheckoutController', 'placeOrder']);
$router->get('/don-hang-thanh-cong/{id}', ['Website\\CheckoutController', 'success']);

$router->get('/tin-tuc', ['Website\\BlogController', 'index']);
$router->get('/tin-tuc/{slug}', ['Website\\BlogController', 'detail']);

$router->get('/ke-toa', ['Website\\PrescriptionController', 'index']);
$router->post('/ke-toa/gui', ['Website\\PrescriptionController', 'submit']);

$router->get('/dang-nhap', ['Website\\AuthController', 'loginForm']);
$router->post('/dang-nhap', ['Website\\AuthController', 'login']);
$router->get('/dang-ky', ['Website\\AuthController', 'registerForm']);
$router->post('/dang-ky', ['Website\\AuthController', 'register']);
$router->get('/dang-xuat', ['Website\\AuthController', 'logout']);

$router->get('/thong-tin', ['Website\\HomeController', 'about']);
$router->get('/lien-he', ['Website\\HomeController', 'contact']);
$router->get('/he-thong-nha-thuoc', ['Website\\HomeController', 'stores']);

$router->post('/yeu-thich/them', ['Website\\WishlistController', 'add']);
$router->post('/yeu-thich/xoa', ['Website\\WishlistController', 'remove']);

$router->post('/binh-luan', ['Website\\ReviewController', 'add']);
