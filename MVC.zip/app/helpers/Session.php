<?php
class Session
{
    public static function init()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public static function set($key, $value)
    {
        $_SESSION[$key] = $value;
    }

    public static function get($key, $default = null)
    {
        return $_SESSION[$key] ?? $default;
    }

    public static function has($key)
    {
        return isset($_SESSION[$key]);
    }

    public static function remove($key)
    {
        unset($_SESSION[$key]);
    }

    public static function destroy()
    {
        session_destroy();
    }

    public static function setFlash($key, $value)
    {
        $_SESSION['_flash'][$key] = $value;
    }

    public static function getFlash($key, $default = null)
    {
        $value = $_SESSION['_flash'][$key] ?? $default;
        unset($_SESSION['_flash'][$key]);
        return $value;
    }

    public static function hasFlash($key)
    {
        return isset($_SESSION['_flash'][$key]);
    }

    public static function isLoggedIn()
    {
        return self::has('user_id');
    }

    public static function isAdmin()
    {
        return self::get('user_role') === 'admin';
    }

    public static function requireLogin()
    {
        self::init();
        if (!self::isLoggedIn()) {
            self::setFlash('error', 'Vui lòng đăng nhập để tiếp tục');
            header('Location: ' . BASE_URL . '/dang-nhap');
            exit;
        }
    }

    public static function requireAdmin()
    {
        self::init();
        if (!self::isAdmin()) {
            self::setFlash('error', 'Bạn không có quyền truy cập');
            header('Location: ' . BASE_URL);
            exit;
        }
    }
}
