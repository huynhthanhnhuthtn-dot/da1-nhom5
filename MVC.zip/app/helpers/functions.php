<?php
function asset($path)
{
    return BASE_URL . '/public/assets/' . ltrim($path, '/');
}

function upload($path)
{
    return BASE_URL . '/public/uploads/' . ltrim($path, '/');
}

function url($path = '')
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function formatPrice($price)
{
    return number_format($price, 0, ',', '.') . '₫';
}

function truncateText($text, $limit = 100)
{
    if (mb_strlen($text) <= $limit) {
        return $text;
    }
    return mb_substr($text, 0, $limit) . '...';
}

function generateSlug($string)
{
    $string = mb_strtolower($string, 'UTF-8');
    $string = preg_replace('/[^\w\s-]/u', '', $string);
    $string = preg_replace('/[\s]+/', '-', $string);
    $string = preg_replace('/-+/', '-', $string);
    return trim($string, '-');
}

function generateSKU($categoryId, $productId, $variantId)
{
    return 'SP' . str_pad($categoryId, 2, '0', STR_PAD_LEFT)
        . str_pad($productId, 4, '0', STR_PAD_LEFT)
        . str_pad($variantId, 3, '0', STR_PAD_LEFT);
}

function uploadFile($file, $folder = 'products')
{
    if (!isset($file['tmp_name']) || empty($file['tmp_name'])) {
        return null;
    }

    $targetDir = PATH_UPLOADS . $folder . DIRECTORY_SEPARATOR;
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $newName = time() . '_' . uniqid() . '.' . $ext;
    $targetPath = $targetDir . $newName;

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return $folder . '/' . $newName;
    }

    return null;
}

function deleteFile($path)
{
    $fullPath = PATH_UPLOADS . str_replace('/', DIRECTORY_SEPARATOR, $path);
    if (file_exists($fullPath)) {
        return unlink($fullPath);
    }
    return false;
}

function getStatusLabel($status)
{
    $labels = [
        'active' => '<span class="badge bg-success">Hoạt động</span>',
        'inactive' => '<span class="badge bg-secondary">Không hoạt động</span>',
        'pending' => '<span class="badge bg-warning">Chờ xử lý</span>',
        'processing' => '<span class="badge bg-info">Đang xử lý</span>',
        'shipping' => '<span class="badge bg-primary">Đang giao</span>',
        'completed' => '<span class="badge bg-success">Hoàn thành</span>',
        'cancelled' => '<span class="badge bg-danger">Đã hủy</span>',
        'confirmed' => '<span class="badge bg-primary">Đã xác nhận</span>',
        'prescription' => '<span class="badge bg-warning">Có toa</span>',
        'over_the_counter' => '<span class="badge bg-info">Không kê đơn</span>',
    ];
    return $labels[$status] ?? $status;
}
