<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold">Danh mục tin tức</h4>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal"><i class="fas fa-plus me-2"></i>Thêm danh mục</button>
</div>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr><th>ID</th><th>Tên danh mục</th><th>Mô tả</th><th>Số bài viết</th><th>Thao tác</th></tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat): ?>
                <tr>
                    <td>#<?= $cat['id_danh_muc_tin'] ?></td>
                    <td><strong><?= htmlspecialchars($cat['ten_danh_muc']) ?></strong></td>
                    <td><?= htmlspecialchars(truncateText($cat['mo_ta'] ?? '', 50)) ?></td>
                    <td><?= $cat['so_luong_bai'] ?></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary edit-cat" data-id="<?= $cat['id_danh_muc_tin'] ?>" data-name="<?= htmlspecialchars($cat['ten_danh_muc']) ?>"><i class="fas fa-edit"></i></button>
                        <form method="post" action="<?= url('admin/danh-muc-tin/xoa/' . $cat['id_danh_muc_tin']) ?>" class="d-inline" onsubmit="return confirm('Xóa?')">
                            <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="addCategoryModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="<?= url('admin/danh-muc-tin/them') ?>">
                <div class="modal-header"><h5 class="modal-title">Thêm danh mục tin</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Tên danh mục</label>
                        <input type="text" name="ten_danh_muc" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Mô tả</label>
                        <textarea name="mo_ta" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Thêm</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editCategoryModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="<?= url('admin/danh-muc-tin/sua') ?>">
                <input type="hidden" name="id" id="editCatId">
                <div class="modal-header"><h5 class="modal-title">Sửa danh mục tin</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Tên danh mục</label>
                        <input type="text" name="ten_danh_muc" id="editCatName" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('.edit-cat').click(function() {
        $('#editCatId').val($(this).data('id'));
        $('#editCatName').val($(this).data('name'));
        $('#editCategoryModal').modal('show');
    });
});
</script>
