<h4 class="fw-bold mb-3">Quản lý đơn hàng</h4>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr><th>Mã đơn</th><th>Người nhận</th><th>SĐT</th><th>Tổng tiền</th><th>Trạng thái</th><th>Ngày đặt</th><th></th></tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                <tr><td colspan="7" class="text-center py-3">Chưa có đơn hàng</td></tr>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($order['ma_don_hang']) ?></strong></td>
                        <td><?= htmlspecialchars($order['nguoi_nhan']) ?></td>
                        <td><?= htmlspecialchars($order['so_dien_thoai']) ?></td>
                        <td class="text-primary fw-bold"><?= formatPrice($order['thanh_tien']) ?></td>
                        <td><?= getStatusLabel($order['trang_thai_don_hang']) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($order['ngay_dat'])) ?></td>
                        <td><a href="<?= url('admin/don-hang/' . $order['id_don_hang']) ?>" class="btn btn-sm btn-outline-primary">Chi tiết</a></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php if ($totalPages > 1): ?>
<nav class="mt-3"><ul class="pagination justify-content-center"><?php for ($i = 1; $i <= $totalPages; $i++): ?><li class="page-item <?= $i == $page ? 'active' : '' ?>"><a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a></li><?php endfor; ?></ul></nav>
<?php endif; ?>
