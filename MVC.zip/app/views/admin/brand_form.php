<h4 class="fw-bold mb-3"><?= $brand ? 'Sửa thương hiệu' : 'Thêm thương hiệu' ?></h4>
<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <form method="post" action="<?= $brand ? url('admin/thuong-hieu/sua/' . $brand['id_thuong_hieu']) : url('admin/thuong-hieu/them') ?>">
            <div class="mb-3">
                <label class="form-label">Tên thương hiệu <span class="text-danger">*</span></label>
                <input type="text" name="ten_thuong_hieu" class="form-control" value="<?= htmlspecialchars($brand['ten_thuong_hieu'] ?? '') ?>" required>
            </div>
            <button type="submit" class="btn btn-primary"><?= $brand ? 'Cập nhật' : 'Thêm mới' ?></button>
            <a href="<?= url('admin/thuong-hieu') ?>" class="btn btn-outline-secondary">Hủy</a>
        </form>
    </div>
</div>
