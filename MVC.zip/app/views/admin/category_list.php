<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold">Quản lý danh mục</h4>
    <a href="<?= url('admin/danh-muc/them') ?>" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Thêm danh mục</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr><th>ID</th><th>Tên danh mục</th><th>Số sản phẩm</th><th>Thao tác</th></tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat): ?>
                <tr>
                    <td>#<?= $cat['id_danh_muc'] ?></td>
                    <td><strong><?= htmlspecialchars($cat['ten_danh_muc']) ?></strong></td>
                    <td><?= $cat['so_luong_san_pham'] ?></td>
                    <td>
                        <a href="<?= url('admin/danh-muc/sua/' . $cat['id_danh_muc']) ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                        <form method="post" action="<?= url('admin/danh-muc/xoa/' . $cat['id_danh_muc']) ?>" class="d-inline" onsubmit="return confirm('Xóa?')">
                            <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
