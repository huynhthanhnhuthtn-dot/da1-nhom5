<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold">Dashboard</h4>
    <small class="text-muted">Hôm nay: <?= date('d/m/Y') ?></small>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title">Đơn hôm nay</h6>
                        <h3 class="fw-bold mb-0"><?= number_format($stats['don_hom_nay']) ?></h3>
                    </div>
                    <i class="fas fa-shopping-cart fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title">Chờ xử lý</h6>
                        <h3 class="fw-bold mb-0"><?= number_format($stats['don_cho_xu_ly']) ?></h3>
                    </div>
                    <i class="fas fa-clock fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title">Tổng đơn</h6>
                        <h3 class="fw-bold mb-0"><?= number_format($stats['tong_don']) ?></h3>
                    </div>
                    <i class="fas fa-check-circle fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title">Doanh thu</h6>
                        <h3 class="fw-bold mb-0"><?= formatPrice($stats['tong_doanh_thu']) ?></h3>
                    </div>
                    <i class="fas fa-dollar-sign fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center">
                <h6 class="text-muted">Tổng sản phẩm</h6>
                <h3 class="fw-bold text-primary"><?= number_format($totalProducts) ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center">
                <h6 class="text-muted">Khách hàng</h6>
                <h3 class="fw-bold text-primary"><?= number_format($totalCustomers) ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center">
                <h6 class="text-muted">Người dùng</h6>
                <h3 class="fw-bold text-primary"><?= number_format($totalUsers) ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body text-center">
                <h6 class="text-muted">Đơn hoàn thành</h6>
                <h3 class="fw-bold text-success"><?= number_format($stats['tong_don'] - $stats['don_cho_xu_ly']) ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-bold">Đơn hàng gần đây</div>
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>Mã đơn</th>
                    <th>Người nhận</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Ngày đặt</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recentOrders)): ?>
                <tr><td colspan="6" class="text-center py-3">Chưa có đơn hàng</td></tr>
                <?php else: ?>
                    <?php foreach ($recentOrders as $order): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($order['ma_don_hang']) ?></strong></td>
                        <td><?= htmlspecialchars($order['nguoi_nhan']) ?></td>
                        <td class="text-primary fw-bold"><?= formatPrice($order['thanh_tien']) ?></td>
                        <td><?= getStatusLabel($order['trang_thai_don_hang']) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($order['ngay_dat'])) ?></td>
                        <td><a href="<?= url('admin/don-hang/' . $order['id_don_hang']) ?>" class="btn btn-sm btn-outline-primary">Chi tiết</a></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
