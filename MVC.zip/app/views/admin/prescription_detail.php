<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold">Chi tiết yêu cầu kê toa #<?= $prescription['id_yeu_cau'] ?></h4>
    <a href="<?= url('admin/yeu-cau-ke-toa') ?>" class="btn btn-outline-secondary">Quay lại</a>
</div>

<div class="row g-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold">Thông tin khách hàng</div>
            <div class="card-body">
                <p><strong>Họ tên:</strong> <?= htmlspecialchars($prescription['ho_ten_khach']) ?></p>
                <p><strong>SĐT:</strong> <?= htmlspecialchars($prescription['so_dien_thoai']) ?></p>
                <p><strong>Triệu chứng:</strong> <?= nl2br(htmlspecialchars($prescription['mo_ta_trieu_chung'])) ?></p>
                <?php if ($prescription['anh_toa_thuoc']): ?>
                <p><strong>Ảnh toa thuốc:</strong></p>
                <img src="<?= upload($prescription['anh_toa_thuoc']) ?>" class="img-fluid rounded" style="max-height: 300px;">
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold">Cập nhật trạng thái</div>
            <div class="card-body">
                <form method="post" action="<?= url('admin/yeu-cau-ke-toa/cap-nhat') ?>">
                    <input type="hidden" name="id" value="<?= $prescription['id_yeu_cau'] ?>">
                    <select name="trang_thai" class="form-select mb-2">
                        <option value="pending" <?= $prescription['trang_thai'] == 'pending' ? 'selected' : '' ?>>Chờ xử lý</option>
                        <option value="processing" <?= $prescription['trang_thai'] == 'processing' ? 'selected' : '' ?>>Đang xử lý</option>
                        <option value="completed" <?= $prescription['trang_thai'] == 'completed' ? 'selected' : '' ?>>Đã xử lý</option>
                        <option value="cancelled" <?= $prescription['trang_thai'] == 'cancelled' ? 'selected' : '' ?>>Từ chối</option>
                    </select>
                    <button type="submit" class="btn btn-primary w-100">Cập nhật</button>
                </form>
            </div>
        </div>
        <?php if (!empty($details)): ?>
        <div class="card border-0 shadow-sm mt-3">
            <div class="card-header bg-white fw-bold">Chi tiết toa thuốc</div>
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead class="table-light">
                        <tr><th>Sản phẩm</th><th>Liều lượng</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($details as $d): ?>
                        <tr>
                            <td><?= htmlspecialchars($d['ten_san_pham']) ?> - <?= htmlspecialchars($d['ten_bien_the']) ?></td>
                            <td><?= htmlspecialchars($d['huong_dan_su_dung']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
