<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold"><?= $product ? 'Sửa sản phẩm' : 'Thêm sản phẩm' ?></h4>
    <a href="<?= url('admin/san-pham') ?>" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-2"></i>Quay lại</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <form method="post" action="<?= $product ? url('admin/san-pham/sua/' . $product['id_san_pham']) : url('admin/san-pham/them') ?>" enctype="multipart/form-data">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Tên sản phẩm <span class="text-danger">*</span></label>
                    <input type="text" name="ten_san_pham" class="form-control" value="<?= htmlspecialchars($product['ten_san_pham'] ?? '') ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Danh mục <span class="text-danger">*</span></label>
                    <select name="danh_muc_id" class="form-select">
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id_danh_muc'] ?>" <?= ($product['danh_muc_id'] ?? '') == $cat['id_danh_muc'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['ten_danh_muc']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Thương hiệu</label>
                    <select name="thuong_hieu_id" class="form-select">
                        <option value="">-- Chọn --</option>
                        <?php foreach ($brands as $brand): ?>
                        <option value="<?= $brand['id_thuong_hieu'] ?>" <?= ($product['thuong_hieu_id'] ?? '') == $brand['id_thuong_hieu'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($brand['ten_thuong_hieu']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Loại thuốc</label>
                    <select name="thuoc_ke_don" class="form-select">
                        <option value="over_the_counter" <?= ($product['thuoc_ke_don'] ?? '') == 'over_the_counter' ? 'selected' : '' ?>>Không kê đơn (OTC)</option>
                        <option value="prescription" <?= ($product['thuoc_ke_don'] ?? '') == 'prescription' ? 'selected' : '' ?>>Kê đơn</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Trạng thái</label>
                    <select name="trang_thai" class="form-select">
                        <option value="active" <?= ($product['trang_thai'] ?? '') == 'active' ? 'selected' : '' ?>>Hoạt động</option>
                        <option value="inactive" <?= ($product['trang_thai'] ?? '') == 'inactive' ? 'selected' : '' ?>>Không hoạt động</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Hình ảnh</label>
                    <input type="file" name="hinh_cover" class="form-control">
                    <?php if (!empty($product['hinh_cover'])): ?>
                        <small class="text-muted">Hiện tại: <?= $product['hinh_cover'] ?></small>
                    <?php endif; ?>
                </div>
                <div class="col-12">
                    <label class="form-label">Mô tả sản phẩm</label>
                    <textarea name="mo_ta" class="form-control" rows="6"><?= htmlspecialchars($product['mo_ta'] ?? '') ?></textarea>
                </div>
            </div>

            <hr class="my-4">
            <h5>Biến thể sản phẩm</h5>
            <div id="variantsContainer">
                <?php if (!empty($variants)): ?>
                    <?php foreach ($variants as $i => $variant): ?>
                    <div class="row g-2 mb-2 variant-row">
                        <div class="col-md-3">
                            <input type="text" name="bien_the[ten][]" class="form-control" placeholder="Tên biến thể" value="<?= htmlspecialchars($variant['ten_bien_the']) ?>">
                        </div>
                        <div class="col-md-2">
                            <input type="text" name="bien_the[don_vi_tinh][]" class="form-control" placeholder="Đơn vị" value="<?= htmlspecialchars($variant['don_vi_tinh']) ?>">
                        </div>
                        <div class="col-md-2">
                            <input type="number" name="bien_the[gia_ban][]" class="form-control" placeholder="Giá bán" value="<?= $variant['gia_ban'] ?>">
                        </div>
                        <div class="col-md-2">
                            <input type="number" name="bien_the[so_luong_ton][]" class="form-control" placeholder="Tồn kho" value="<?= $variant['so_luong_ton'] ?>">
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-danger remove-variant"><i class="fas fa-times"></i></button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                <div class="row g-2 mb-2 variant-row">
                    <div class="col-md-3"><input type="text" name="bien_the[ten][]" class="form-control" placeholder="Tên biến thể" value="Mặc định"></div>
                    <div class="col-md-2"><input type="text" name="bien_the[don_vi_tinh][]" class="form-control" placeholder="Đơn vị" value="Hộp"></div>
                    <div class="col-md-2"><input type="number" name="bien_the[gia_ban][]" class="form-control" placeholder="Giá bán"></div>
                    <div class="col-md-2"><input type="number" name="bien_the[so_luong_ton][]" class="form-control" placeholder="Tồn kho"></div>
                    <div class="col-md-2"><button type="button" class="btn btn-danger remove-variant"><i class="fas fa-times"></i></button></div>
                </div>
                <?php endif; ?>
            </div>
            <button type="button" class="btn btn-outline-primary btn-sm mt-2" id="addVariantBtn"><i class="fas fa-plus me-1"></i>Thêm biến thể</button>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary px-4"><?= $product ? 'Cập nhật' : 'Thêm mới' ?></button>
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#addVariantBtn').click(function() {
        var html = '<div class="row g-2 mb-2 variant-row">\
            <div class="col-md-3"><input type="text" name="bien_the[ten][]" class="form-control" placeholder="Tên biến thể"></div>\
            <div class="col-md-2"><input type="text" name="bien_the[don_vi_tinh][]" class="form-control" placeholder="Đơn vị"></div>\
            <div class="col-md-2"><input type="number" name="bien_the[gia_ban][]" class="form-control" placeholder="Giá bán"></div>\
            <div class="col-md-2"><input type="number" name="bien_the[so_luong_ton][]" class="form-control" placeholder="Tồn kho"></div>\
            <div class="col-md-2"><button type="button" class="btn btn-danger remove-variant"><i class="fas fa-times"></i></button></div>\
        </div>';
        $('#variantsContainer').append(html);
    });

    $(document).on('click', '.remove-variant', function() {
        $(this).closest('.variant-row').remove();
    });
});
</script>
