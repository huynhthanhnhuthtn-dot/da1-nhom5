<h4 class="fw-bold mb-3">Quản lý người dùng</h4>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr><th>ID</th><th>Họ tên</th><th>Email</th><th>SĐT</th><th>Tên đăng nhập</th><th>Vai trò</th><th>Trạng thái</th><th>Thao tác</th></tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td>#<?= $user['id_nguoi_dung'] ?></td>
                    <td><?= htmlspecialchars($user['ho_ten']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td><?= htmlspecialchars($user['so_dien_thoai']) ?></td>
                    <td><?= htmlspecialchars($user['ten_user']) ?></td>
                    <td><?= $user['vai_tro'] === 'admin' ? '<span class="badge bg-danger">Admin</span>' : '<span class="badge bg-info">Khách hàng</span>' ?></td>
                    <td><?= getStatusLabel($user['trang_thai']) ?></td>
                    <td><a href="<?= url('admin/nguoi-dung/sua/' . $user['id_nguoi_dung']) ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php if ($totalPages > 1): ?>
<nav class="mt-3"><ul class="pagination justify-content-center"><?php for ($i = 1; $i <= $totalPages; $i++): ?><li class="page-item <?= $i == $page ? 'active' : '' ?>"><a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a></li><?php endfor; ?></ul></nav>
<?php endif; ?>
