<h4 class="fw-bold mb-3"><?= $post ? 'Sửa bài viết' : 'Thêm bài viết' ?></h4>
<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <form method="post" action="<?= $post ? url('admin/tin-tuc/sua/' . $post['id_tin_tuc']) : url('admin/tin-tuc/them') ?>" enctype="multipart/form-data">
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Tiêu đề <span class="text-danger">*</span></label>
                    <input type="text" name="tieu_de" class="form-control" value="<?= htmlspecialchars($post['tieu_de'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Danh mục <span class="text-danger">*</span></label>
                    <select name="danh_muc_tin_id" class="form-select">
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id_danh_muc_tin'] ?>" <?= ($post['danh_muc_tin_id'] ?? '') == $cat['id_danh_muc_tin'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['ten_danh_muc']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Trạng thái</label>
                    <select name="trang_thai" class="form-select">
                        <option value="active" <?= ($post['trang_thai'] ?? '') == 'active' ? 'selected' : '' ?>>Hoạt động</option>
                        <option value="inactive" <?= ($post['trang_thai'] ?? '') == 'inactive' ? 'selected' : '' ?>>Ẩn</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Hình ảnh đại diện</label>
                    <input type="file" name="hinh_anh_dai_dien" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Slug (để trống tự động tạo)</label>
                    <input type="text" class="form-control" disabled value="<?= htmlspecialchars($post['slug'] ?? '') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">Tóm tắt</label>
                    <textarea name="tom_tat" class="form-control" rows="3"><?= htmlspecialchars($post['tom_tat'] ?? '') ?></textarea>
                </div>
                <div class="col-12">
                    <label class="form-label">Nội dung <span class="text-danger">*</span></label>
                    <textarea name="noi_dung" class="form-control" rows="15"><?= htmlspecialchars($post['noi_dung'] ?? '') ?></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-3"><?= $post ? 'Cập nhật' : 'Thêm mới' ?></button>
            <a href="<?= url('admin/tin-tuc') ?>" class="btn btn-outline-secondary mt-3">Hủy</a>
        </form>
    </div>
</div>
