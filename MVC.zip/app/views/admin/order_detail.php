<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold">Chi tiết đơn hàng #<?= htmlspecialchars($order['ma_don_hang']) ?></h4>
    <a href="<?= url('admin/don-hang') ?>" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-2"></i>Quay lại</a>
</div>

<div class="row g-4">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-header bg-white fw-bold">Sản phẩm</div>
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead class="table-light">
                        <tr><th>Sản phẩm</th><th>Phân loại</th><th>Đơn giá</th><th>Số lượng</th><th>Thành tiền</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['ten_san_pham']) ?></td>
                            <td><?= htmlspecialchars($item['ten_bien_the']) ?></td>
                            <td><?= formatPrice($item['gia_ban']) ?></td>
                            <td><?= $item['so_luong'] ?></td>
                            <td class="fw-bold"><?= formatPrice($item['gia_ban'] * $item['so_luong']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-header bg-white fw-bold">Thông tin giao hàng</div>
            <div class="card-body">
                <p class="mb-1"><strong>Người nhận:</strong> <?= htmlspecialchars($order['nguoi_nhan']) ?></p>
                <p class="mb-1"><strong>SĐT:</strong> <?= htmlspecialchars($order['so_dien_thoai']) ?></p>
                <p class="mb-1"><strong>Địa chỉ:</strong> <?= htmlspecialchars($order['dia_chi_giao_hang']) ?></p>
            </div>
        </div>
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-header bg-white fw-bold">Thanh toán</div>
            <div class="card-body">
                <p class="mb-1">Tạm tính: <?= formatPrice($order['tong_tien_hang']) ?></p>
                <p class="mb-1">Phí ship: <?= formatPrice($order['phi_van_chuyen']) ?></p>
                <p class="mb-1">Giảm giá: <?= formatPrice($order['giam_gia']) ?></p>
                <hr>
                <p class="fw-bold text-primary h5"><?= formatPrice($order['thanh_tien']) ?></p>
            </div>
        </div>
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-bold">Cập nhật trạng thái</div>
            <div class="card-body">
                <form method="post" action="<?= url('admin/don-hang/cap-nhat-trang-thai') ?>">
                    <input type="hidden" name="id" value="<?= $order['id_don_hang'] ?>">
                    <select name="trang_thai" class="form-select mb-2">
                        <option value="pending" <?= $order['trang_thai_don_hang'] == 'pending' ? 'selected' : '' ?>>Chờ xử lý</option>
                        <option value="confirmed" <?= $order['trang_thai_don_hang'] == 'confirmed' ? 'selected' : '' ?>>Đã xác nhận</option>
                        <option value="processing" <?= $order['trang_thai_don_hang'] == 'processing' ? 'selected' : '' ?>>Đang xử lý</option>
                        <option value="shipping" <?= $order['trang_thai_don_hang'] == 'shipping' ? 'selected' : '' ?>>Đang giao</option>
                        <option value="completed" <?= $order['trang_thai_don_hang'] == 'completed' ? 'selected' : '' ?>>Hoàn thành</option>
                        <option value="cancelled" <?= $order['trang_thai_don_hang'] == 'cancelled' ? 'selected' : '' ?>>Đã hủy</option>
                    </select>
                    <button type="submit" class="btn btn-primary w-100">Cập nhật</button>
                </form>
            </div>
        </div>
    </div>
</div>
