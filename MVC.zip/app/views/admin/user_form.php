<h4 class="fw-bold mb-3">Sửa người dùng</h4>
<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <form method="post" action="<?= url('admin/nguoi-dung/sua/' . $user['id_nguoi_dung']) ?>">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Họ tên</label>
                    <input type="text" name="ho_ten" class="form-control" value="<?= htmlspecialchars($user['ho_ten']) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Số điện thoại</label>
                    <input type="text" name="so_dien_thoai" class="form-control" value="<?= htmlspecialchars($user['so_dien_thoai']) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Vai trò</label>
                    <select name="vai_tro" class="form-select">
                        <option value="customer" <?= $user['vai_tro'] == 'customer' ? 'selected' : '' ?>>Khách hàng</option>
                        <option value="admin" <?= $user['vai_tro'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Trạng thái</label>
                    <select name="trang_thai" class="form-select">
                        <option value="active" <?= $user['trang_thai'] == 'active' ? 'selected' : '' ?>>Hoạt động</option>
                        <option value="inactive" <?= $user['trang_thai'] == 'inactive' ? 'selected' : '' ?>>Không hoạt động</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Mật khẩu mới (để trống nếu không đổi)</label>
                    <input type="password" name="mat_khau" class="form-control">
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Cập nhật</button>
            <a href="<?= url('admin/nguoi-dung') ?>" class="btn btn-outline-secondary mt-3">Hủy</a>
        </form>
    </div>
</div>
