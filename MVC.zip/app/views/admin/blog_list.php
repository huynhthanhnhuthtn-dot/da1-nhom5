<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold">Quản lý tin tức</h4>
    <a href="<?= url('admin/tin-tuc/them') ?>" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Thêm bài viết</a>
</div>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr><th>ID</th><th>Hình</th><th>Tiêu đề</th><th>Danh mục</th><th>Lượt xem</th><th>Trạng thái</th><th>Ngày tạo</th><th>Thao tác</th></tr>
            </thead>
            <tbody>
                <?php if (empty($posts)): ?>
                <tr><td colspan="8" class="text-center py-3">Chưa có bài viết</td></tr>
                <?php else: ?>
                    <?php foreach ($posts as $post): ?>
                    <tr>
                        <td>#<?= $post['id_tin_tuc'] ?></td>
                        <td><img src="<?= $post['hinh_anh_dai_dien'] ? upload($post['hinh_anh_dai_dien']) : 'https://placehold.co/50x50' ?>" style="width: 50px; height: 50px; object-fit: cover;" class="rounded"></td>
                        <td><?= htmlspecialchars($post['tieu_de']) ?></td>
                        <td><?= htmlspecialchars($post['ten_danh_muc'] ?? '') ?></td>
                        <td><?= $post['luot_xem'] ?></td>
                        <td><?= getStatusLabel($post['trang_thai']) ?></td>
                        <td><?= date('d/m/Y', strtotime($post['ngay_tao'])) ?></td>
                        <td>
                            <a href="<?= url('admin/tin-tuc/sua/' . $post['id_tin_tuc']) ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                            <form method="post" action="<?= url('admin/tin-tuc/xoa/' . $post['id_tin_tuc']) ?>" class="d-inline" onsubmit="return confirm('Xóa?')">
                                <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php if ($totalPages > 1): ?>
<nav class="mt-3"><ul class="pagination justify-content-center"><?php for ($i = 1; $i <= $totalPages; $i++): ?><li class="page-item <?= $i == $page ? 'active' : '' ?>"><a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a></li><?php endfor; ?></ul></nav>
<?php endif; ?>
