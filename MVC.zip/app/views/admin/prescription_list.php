<h4 class="fw-bold mb-3">Yêu cầu kê toa</h4>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr><th>ID</th><th>Họ tên</th><th>SĐT</th><th>Mô tả</th><th>Trạng thái</th><th>Ngày gửi</th><th></th></tr>
            </thead>
            <tbody>
                <?php foreach ($prescriptions as $p): ?>
                <tr>
                    <td>#<?= $p['id_yeu_cau'] ?></td>
                    <td><?= htmlspecialchars($p['ho_ten_khach']) ?></td>
                    <td><?= htmlspecialchars($p['so_dien_thoai']) ?></td>
                    <td class="text-truncate" style="max-width: 200px;"><?= htmlspecialchars($p['mo_ta_trieu_chung']) ?></td>
                    <td><?= getStatusLabel($p['trang_thai']) ?></td>
                    <td><?= date('d/m/Y H:i', strtotime($p['ngay_gui'])) ?></td>
                    <td><a href="<?= url('admin/yeu-cau-ke-toa/' . $p['id_yeu_cau']) ?>" class="btn btn-sm btn-outline-primary">Chi tiết</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
