<h4 class="fw-bold mb-3"><?= $coupon ? 'Sửa khuyến mãi' : 'Thêm khuyến mãi' ?></h4>
<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <form method="post" action="<?= $coupon ? url('admin/khuyen-mai/sua/' . $coupon['id_khuyen_mai']) : url('admin/khuyen-mai/them') ?>">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Tên khuyến mãi <span class="text-danger">*</span></label>
                    <input type="text" name="ten_khuyen_mai" class="form-control" value="<?= htmlspecialchars($coupon['ten_khuyen_mai'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Mã khuyến mãi <span class="text-danger">*</span></label>
                    <input type="text" name="ma_khuyen_mai" class="form-control" value="<?= htmlspecialchars($coupon['ma_khuyen_mai'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Giá trị giảm <span class="text-danger">*</span></label>
                    <input type="number" name="gia_tri_giam" class="form-control" value="<?= $coupon['gia_tri_giam'] ?? '' ?>" step="0.01" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Loại giảm giá</label>
                    <select name="loai_giam_gia" class="form-select">
                        <option value="percent" <?= ($coupon['loai_giam_gia'] ?? '') == 'percent' ? 'selected' : '' ?>>Phần trăm (%)</option>
                        <option value="fixed" <?= ($coupon['loai_giam_gia'] ?? '') == 'fixed' ? 'selected' : '' ?>>Cố định (VNĐ)</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Ngày bắt đầu</label>
                    <input type="datetime-local" name="ngay_bat_dau" class="form-control" value="<?= isset($coupon['ngay_bat_dau']) ? date('Y-m-d\TH:i', strtotime($coupon['ngay_bat_dau'])) : '' ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Ngày kết thúc</label>
                    <input type="datetime-local" name="ngay_ket_thuc" class="form-control" value="<?= isset($coupon['ngay_ket_thuc']) ? date('Y-m-d\TH:i', strtotime($coupon['ngay_ket_thuc'])) : '' ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-3"><?= $coupon ? 'Cập nhật' : 'Thêm mới' ?></button>
            <a href="<?= url('admin/khuyen-mai') ?>" class="btn btn-outline-secondary mt-3">Hủy</a>
        </form>
    </div>
</div>
