<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold">Quản lý khuyến mãi</h4>
    <a href="<?= url('admin/khuyen-mai/them') ?>" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Thêm khuyến mãi</a>
</div>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr><th>ID</th><th>Tên</th><th>Mã</th><th>Giá trị</th><th>Loại</th><th>Bắt đầu</th><th>Kết thúc</th><th>Thao tác</th></tr>
            </thead>
            <tbody>
                <?php foreach ($coupons as $coupon): ?>
                <tr>
                    <td>#<?= $coupon['id_khuyen_mai'] ?></td>
                    <td><?= htmlspecialchars($coupon['ten_khuyen_mai']) ?></td>
                    <td><span class="badge bg-primary"><?= htmlspecialchars($coupon['ma_khuyen_mai']) ?></span></td>
                    <td class="fw-bold"><?= $coupon['loai_giam_gia'] === 'percent' ? $coupon['gia_tri_giam'] . '%' : formatPrice($coupon['gia_tri_giam']) ?></td>
                    <td><?= $coupon['loai_giam_gia'] === 'percent' ? '%' : 'VNĐ' ?></td>
                    <td><small><?= date('d/m/Y', strtotime($coupon['ngay_bat_dau'])) ?></small></td>
                    <td><small><?= date('d/m/Y', strtotime($coupon['ngay_ket_thuc'])) ?></small></td>
                    <td>
                        <a href="<?= url('admin/khuyen-mai/sua/' . $coupon['id_khuyen_mai']) ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                        <form method="post" action="<?= url('admin/khuyen-mai/xoa/' . $coupon['id_khuyen_mai']) ?>" class="d-inline" onsubmit="return confirm('Xóa?')">
                            <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
