<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold">Quản lý thương hiệu</h4>
    <a href="<?= url('admin/thuong-hieu/them') ?>" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Thêm thương hiệu</a>
</div>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr><th>ID</th><th>Tên thương hiệu</th><th>Số sản phẩm</th><th>Thao tác</th></tr>
            </thead>
            <tbody>
                <?php foreach ($brands as $brand): ?>
                <tr>
                    <td>#<?= $brand['id_thuong_hieu'] ?></td>
                    <td><strong><?= htmlspecialchars($brand['ten_thuong_hieu']) ?></strong></td>
                    <td><?= $brand['so_luong_san_pham'] ?></td>
                    <td>
                        <a href="<?= url('admin/thuong-hieu/sua/' . $brand['id_thuong_hieu']) ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                        <form method="post" action="<?= url('admin/thuong-hieu/xoa/' . $brand['id_thuong_hieu']) ?>" class="d-inline" onsubmit="return confirm('Xóa?')">
                            <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
