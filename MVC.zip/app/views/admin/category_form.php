<h4 class="fw-bold mb-3"><?= $category ? 'Sửa danh mục' : 'Thêm danh mục' ?></h4>
<div class="card border-0 shadow-sm">
    <div class="card-body p-4">
        <form method="post" action="<?= $category ? url('admin/danh-muc/sua/' . $category['id_danh_muc']) : url('admin/danh-muc/them') ?>">
            <div class="mb-3">
                <label class="form-label">Tên danh mục <span class="text-danger">*</span></label>
                <input type="text" name="ten_danh_muc" class="form-control" value="<?= htmlspecialchars($category['ten_danh_muc'] ?? '') ?>" required>
            </div>
            <button type="submit" class="btn btn-primary"><?= $category ? 'Cập nhật' : 'Thêm mới' ?></button>
            <a href="<?= url('admin/danh-muc') ?>" class="btn btn-outline-secondary">Hủy</a>
        </form>
    </div>
</div>
