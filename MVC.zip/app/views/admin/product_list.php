<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold">Quản lý sản phẩm</h4>
    <a href="<?= url('admin/san-pham/them') ?>" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Thêm sản phẩm</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Hình</th>
                    <th>Tên sản phẩm</th>
                    <th>Danh mục</th>
                    <th>Thương hiệu</th>
                    <th>Loại</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                <tr><td colspan="8" class="text-center py-4">Chưa có sản phẩm nào</td></tr>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                    <tr>
                        <td>#<?= $product['id_san_pham'] ?></td>
                        <td>
                            <img src="<?= $product['hinh_cover'] ? upload($product['hinh_cover']) : 'https://placehold.co/50x50' ?>" 
                                 style="width: 50px; height: 50px; object-fit: cover;" class="rounded">
                        </td>
                        <td><strong><?= htmlspecialchars($product['ten_san_pham']) ?></strong></td>
                        <td><?= htmlspecialchars($product['ten_danh_muc'] ?? '') ?></td>
                        <td><?= htmlspecialchars($product['ten_thuong_hieu'] ?? '') ?></td>
                        <td><?= $product['thuoc_ke_don'] === 'prescription' ? '<span class="badge bg-warning">Kê đơn</span>' : '<span class="badge bg-info">OTC</span>' ?></td>
                        <td><?= getStatusLabel($product['trang_thai']) ?></td>
                        <td>
                            <a href="<?= url('admin/san-pham/sua/' . $product['id_san_pham']) ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                            <form method="post" action="<?= url('admin/san-pham/xoa/' . $product['id_san_pham']) ?>" class="d-inline" onsubmit="return confirm('Xóa sản phẩm này?')">
                                <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination justify-content-center">
        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?page=<?= $page - 1 ?>">Trước</a></li>
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <li class="page-item <?= $i == $page ? 'active' : '' ?>"><a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a></li>
        <?php endfor; ?>
        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?page=<?= $page + 1 ?>">Sau</a></li>
    </ul>
</nav>
<?php endif; ?>
