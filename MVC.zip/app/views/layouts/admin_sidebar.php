<nav id="sidebar" class="bg-dark text-white" style="width: 250px; min-height: 100vh;">
    <div class="sidebar-header p-3 text-center border-bottom border-secondary">
        <h5 class="mb-0"><?= SITE_NAME ?></h5>
        <small>Quản trị hệ thống</small>
    </div>
    <ul class="nav flex-column p-2">
        <li class="nav-item">
            <a class="nav-link text-white" href="<?= url('admin') ?>"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="<?= url('admin/don-hang') ?>"><i class="fas fa-shopping-cart me-2"></i>Đơn hàng</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="<?= url('admin/san-pham') ?>"><i class="fas fa-pills me-2"></i>Sản phẩm</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="<?= url('admin/danh-muc') ?>"><i class="fas fa-tags me-2"></i>Danh mục</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="<?= url('admin/thuong-hieu') ?>"><i class="fas fa-building me-2"></i>Thương hiệu</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="<?= url('admin/tin-tuc') ?>"><i class="fas fa-newspaper me-2"></i>Tin tức</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="<?= url('admin/danh-muc-tin') ?>"><i class="fas fa-folder me-2"></i>Danh mục tin</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="<?= url('admin/khuyen-mai') ?>"><i class="fas fa-gift me-2"></i>Khuyến mãi</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="<?= url('admin/yeu-cau-ke-toa') ?>"><i class="fas fa-file-prescription me-2"></i>Yêu cầu kê toa</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="<?= url('admin/nguoi-dung') ?>"><i class="fas fa-users me-2"></i>Người dùng</a>
        </li>
    </ul>
</nav>
