<footer id="footer" class="bg-dark text-light pt-5 pb-3">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4">
                <h5 class="text-primary mb-3"><?= SITE_NAME ?></h5>
                <p><?= SITE_SLOGAN ?> - Uy tín hơn 30 năm trong lĩnh vực dược phẩm và chăm sóc sức khỏe.</p>
                <p><i class="fas fa-map-marker-alt me-2"></i> 123 Đường ABC, Quận 1, TP. Hồ Chí Minh</p>
                <p><i class="fas fa-phone me-2"></i> Hotline: 1900 1234</p>
                <p><i class="fas fa-envelope me-2"></i> info@nhathuoc5.vn</p>
            </div>
            <div class="col-lg-2">
                <h5 class="mb-3">Danh mục</h5>
                <ul class="list-unstyled">
                    <?php
                    $catModel = new \Category();
                    $cats = $catModel->getAll();
                    foreach (array_slice($cats, 0, 6) as $cat): ?>
                        <li class="mb-2"><a href="<?= url('san-pham?danh_muc=' . $cat['id_danh_muc']) ?>" class="text-light text-decoration-none"><?= htmlspecialchars($cat['ten_danh_muc']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="col-lg-3">
                <h5 class="mb-3">Chính sách</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><a href="#" class="text-light text-decoration-none">Chính sách bảo hành</a></li>
                    <li class="mb-2"><a href="#" class="text-light text-decoration-none">Chính sách đổi trả</a></li>
                    <li class="mb-2"><a href="#" class="text-light text-decoration-none">Chính sách vận chuyển</a></li>
                    <li class="mb-2"><a href="#" class="text-light text-decoration-none">Chính sách bảo mật</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h5 class="mb-3">Kết nối với chúng tôi</h5>
                <div class="social-links mb-3">
                    <a href="#" class="btn btn-outline-light btn-sm me-1"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="btn btn-outline-light btn-sm me-1"><i class="fab fa-youtube"></i></a>
                    <a href="#" class="btn btn-outline-light btn-sm me-1"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="btn btn-outline-light btn-sm"><i class="fab fa-zalo"></i></a>
                </div>
                <p class="mb-1"><small>Đăng ký nhận tin khuyến mãi:</small></p>
                <form class="input-group">
                    <input type="email" class="form-control form-control-sm" placeholder="Email của bạn">
                    <button class="btn btn-primary btn-sm" type="submit">Đăng ký</button>
                </form>
            </div>
        </div>
        <hr class="my-4">
        <div class="text-center">
            <small>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. Tất cả quyền được bảo lưu.</small>
        </div>
    </div>
</footer>
