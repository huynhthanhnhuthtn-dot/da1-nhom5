<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? SITE_NAME ?> - <?= SITE_NAME ?></title>
    <meta name="description" content="Hệ thống nhà thuốc lớn số 1 VN - Uy tín hơn 30 năm">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= asset('css/website.css') ?>">
    <script>var BASE_URL = '<?= BASE_URL ?>';</script>
</head>
<body>
    <div id="wrapper">
        <?php require_once PATH_VIEWS . 'layouts' . DIRECTORY_SEPARATOR . 'website_header.php'; ?>
        <main>
            <?php
            $flashError = \Session::getFlash('error');
            $flashSuccess = \Session::getFlash('success');
            if ($flashError): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($flashError) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($flashSuccess): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($flashSuccess) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?= $content ?? '' ?>
        </main>
        <?php require_once PATH_VIEWS . 'layouts' . DIRECTORY_SEPARATOR . 'website_footer.php'; ?>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="<?= asset('js/website.js') ?>"></script>
</body>
</html>
