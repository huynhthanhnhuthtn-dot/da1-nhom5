<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Dashboard' ?> - <?= SITE_NAME ?> Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= asset('css/admin.css') ?>">
    <script>var BASE_URL = '<?= BASE_URL ?>';</script>
</head>
<body>
    <div class="d-flex" id="admin-wrapper">
        <?php require_once PATH_VIEWS . 'layouts' . DIRECTORY_SEPARATOR . 'admin_sidebar.php'; ?>
        <div id="admin-content" class="flex-grow-1">
            <?php require_once PATH_VIEWS . 'layouts' . DIRECTORY_SEPARATOR . 'admin_header.php'; ?>
            <div class="container-fluid p-4">
                <?php
                $flashError = \Session::getFlash('error');
                $flashSuccess = \Session::getFlash('success');
                if ($flashError): ?>
                    <div class="alert alert-danger alert-dismissible fade show"><?= htmlspecialchars($flashError) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
                <?php endif; ?>
                <?php if ($flashSuccess): ?>
                    <div class="alert alert-success alert-dismissible fade show"><?= htmlspecialchars($flashSuccess) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
                <?php endif; ?>
                <?= $content ?? '' ?>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="<?= asset('js/admin.js') ?>"></script>
</body>
</html>
