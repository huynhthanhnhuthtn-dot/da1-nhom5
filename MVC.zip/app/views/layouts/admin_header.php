<nav class="navbar navbar-expand navbar-dark bg-primary px-3">
    <a class="navbar-brand" href="<?= url('admin') ?>"><?= SITE_NAME ?> - Admin</a>
    <ul class="navbar-nav ms-auto">
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                <i class="fas fa-user me-1"></i><?= htmlspecialchars(\Session::get('user_name')) ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="<?= BASE_URL ?>"><i class="fas fa-external-link-alt me-2"></i>Xem website</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?= url('admin/dang-xuat') ?>"><i class="fas fa-sign-out-alt me-2"></i>Đăng xuất</a></li>
            </ul>
        </li>
    </ul>
</nav>
