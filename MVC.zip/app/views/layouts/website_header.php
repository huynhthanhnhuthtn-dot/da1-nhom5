<header id="header">
    <div class="top-bar bg-primary text-white py-1">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                    <small><i class="fas fa-phone-alt me-1"></i> Hotline: 1900 1234</small>
                    <small class="ms-3"><i class="fas fa-envelope me-1"></i> info@nhathuoc5.vn</small>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <?php if (\Session::isLoggedIn()): ?>
                        <a href="#" class="text-white me-2"><small><i class="fas fa-user me-1"></i><?= htmlspecialchars(\Session::get('user_name')) ?></small></a>
                        <a href="<?= url('dang-xuat') ?>" class="text-white"><small><i class="fas fa-sign-out-alt me-1"></i>Đăng xuất</small></a>
                    <?php else: ?>
                        <a href="<?= url('dang-nhap') ?>" class="text-white me-2"><small><i class="fas fa-sign-in-alt me-1"></i>Đăng nhập</small></a>
                        <a href="<?= url('dang-ky') ?>" class="text-white"><small><i class="fas fa-user-plus me-1"></i>Đăng ký</small></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="middle-header py-3">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-3 col-md-4">
                    <a href="<?= BASE_URL ?>" class="logo">
                        <h1 class="h4 mb-0 text-primary fw-bold"><?= SITE_NAME ?></h1>
                        <small class="text-muted"><?= SITE_SLOGAN ?></small>
                    </a>
                </div>
                <div class="col-lg-6 col-md-4 my-2 my-md-0">
                    <form action="<?= url('san-pham') ?>" method="GET" class="search-form">
                        <div class="input-group">
                            <input type="text" name="keyword" class="form-control" placeholder="Tìm kiếm sản phẩm..." value="<?= htmlspecialchars($_GET['keyword'] ?? '') ?>">
                            <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                        </div>
                    </form>
                </div>
                <div class="col-lg-3 col-md-4 text-end">
                    <a href="<?= url('gio-hang') ?>" class="btn btn-outline-primary position-relative">
                        <i class="fas fa-shopping-cart"></i> Giỏ hàng
                        <span class="badge bg-danger cart-count">0</span>
                    </a>
                    <a href="<?= url('ke-toa') ?>" class="btn btn-warning ms-2">
                        <i class="fas fa-file-prescription"></i> Kê toa
                    </a>
                </div>
            </div>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>"><i class="fas fa-home"></i> Trang chủ</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Danh mục</a>
                        <ul class="dropdown-menu">
                            <?php
                            $catModel = new \Category();
                            $cats = $catModel->getAll();
                            foreach ($cats as $cat): ?>
                                <li><a class="dropdown-item" href="<?= url('san-pham?danh_muc=' . $cat['id_danh_muc']) ?>"><?= htmlspecialchars($cat['ten_danh_muc']) ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="<?= url('san-pham') ?>">Sản phẩm</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= url('tin-tuc') ?>">Góc sức khỏe</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= url('he-thong-nha-thuoc') ?>">Hệ thống nhà thuốc</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= url('lien-he') ?>">Liên hệ</a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>
