<section class="page-banner bg-primary text-white py-4">
    <div class="container">
        <h4 class="mb-1">Gửi đơn thuốc</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>" class="text-white">Trang chủ</a></li>
                <li class="breadcrumb-item active text-white-50">Gửi đơn thuốc</li>
            </ol>
        </nav>
    </div>
</section>

<section class="py-4">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white fw-bold">
                        <i class="fas fa-file-prescription me-2"></i>Thông tin đơn thuốc
                    </div>
                    <div class="card-body p-4">
                        <form method="post" action="<?= url('ke-toa/gui') ?>" enctype="multipart/form-data">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Họ tên <span class="text-danger">*</span></label>
                                    <input type="text" name="ho_ten" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Số điện thoại <span class="text-danger">*</span></label>
                                    <input type="text" name="so_dien_thoai" class="form-control" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Mô tả triệu chứng</label>
                                    <textarea name="trieu_chung" class="form-control" rows="4" placeholder="Mô tả triệu chứng của bạn..."></textarea>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Hình ảnh toa thuốc</label>
                                    <input type="file" name="anh_toa_thuoc" class="form-control" accept="image/*">
                                    <small class="text-muted">Chụp ảnh đơn thuốc của bạn (nếu có)</small>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary btn-lg w-100">
                                        <i class="fas fa-paper-plane me-2"></i>Gửi đơn thuốc
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-body p-4">
                        <h5><i class="fas fa-info-circle text-primary me-2"></i>Quy trình xử lý</h5>
                        <ol class="mt-3">
                            <li class="mb-2">Bạn gửi đơn thuốc kèm triệu chứng</li>
                            <li class="mb-2">Dược sĩ của chúng tôi sẽ xem xét đơn thuốc</li>
                            <li class="mb-2">Dược sĩ tư vấn và xác nhận đơn hàng</li>
                            <li class="mb-2">Thuốc được giao đến tận nhà bạn</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
