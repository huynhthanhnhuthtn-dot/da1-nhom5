<section class="page-banner bg-primary text-white py-4">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>" class="text-white">Trang chủ</a></li>
                <li class="breadcrumb-item"><a href="<?= url('san-pham') ?>" class="text-white">Sản phẩm</a></li>
                <li class="breadcrumb-item active text-white-50"><?= htmlspecialchars($product['ten_san_pham']) ?></li>
            </ol>
        </nav>
    </div>
</section>

<section class="py-4">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-5">
                <div class="product-images">
                    <img src="<?= $product['hinh_cover'] ? upload($product['hinh_cover']) : 'https://placehold.co/500x500/e0e0e0/666666?text=No+Image' ?>" 
                         class="img-fluid rounded shadow-sm w-100" alt="<?= htmlspecialchars($product['ten_san_pham']) ?>"
                         style="height: 400px; object-fit: cover;">
                    <?php if (!empty($product['danh_sach_hinh_nho'])): ?>
                    <div class="row g-2 mt-2">
                        <?php foreach ($product['danh_sach_hinh_nho'] as $img): ?>
                        <div class="col-3">
                            <img src="<?= upload($img) ?>" class="img-fluid rounded border" style="height: 80px; object-fit: cover; cursor: pointer;">
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-7">
                <h3 class="fw-bold"><?= htmlspecialchars($product['ten_san_pham']) ?></h3>
                <?php if ($product['thuong_hieu_id']): ?>
                    <p class="text-muted">Thương hiệu: <strong><?= htmlspecialchars($product['ten_thuong_hieu'] ?? '') ?></strong></p>
                <?php endif; ?>
                <?php if ($product['danh_muc_id']): ?>
                    <p class="text-muted">Danh mục: <strong><?= htmlspecialchars($product['ten_danh_muc'] ?? '') ?></strong></p>
                <?php endif; ?>
                
                <?php if ($product['thuoc_ke_don'] === 'prescription'): ?>
                    <div class="alert alert-warning"><i class="fas fa-exclamation-triangle me-2"></i>Thuốc kê đơn - Cần có đơn thuốc của bác sĩ</div>
                <?php endif; ?>

                <hr>

                <?php if (!empty($variants)): ?>
                <form id="addToCartForm" method="post">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Chọn phân loại:</label>
                        <?php foreach ($variants as $i => $variant): ?>
                        <div class="form-check">
                            <input class="form-check-input variant-radio" type="radio" name="bien_the_id" 
                                   value="<?= $variant['id_bien_the'] ?>" 
                                   data-price="<?= $variant['gia_ban'] ?>"
                                   data-stock="<?= $variant['so_luong_ton'] ?>"
                                   <?= $i === 0 ? 'checked' : '' ?>>
                            <label class="form-check-label">
                                <?= htmlspecialchars($variant['ten_bien_the']) ?> 
                                (<?= htmlspecialchars($variant['don_vi_tinh']) ?>) - 
                                <span class="text-primary fw-bold"><?= formatPrice($variant['gia_ban']) ?></span>
                                <?php if ($variant['so_luong_ton'] <= 0): ?>
                                    <span class="badge bg-danger">Hết hàng</span>
                                <?php endif; ?>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Số lượng:</label>
                        <div class="input-group" style="width: 140px;">
                            <button type="button" class="btn btn-outline-secondary" id="qtyMinus">-</button>
                            <input type="number" name="so_luong" id="quantity" class="form-control text-center" value="1" min="1">
                            <button type="button" class="btn btn-outline-secondary" id="qtyPlus">+</button>
                        </div>
                    </div>

                    <div class="mb-3">
                        <span class="h4 text-primary fw-bold" id="displayPrice"><?= formatPrice($variants[0]['gia_ban']) ?></span>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-primary btn-lg flex-grow-1" id="addToCartBtn">
                            <i class="fas fa-cart-plus me-2"></i>Thêm vào giỏ hàng
                        </button>
                        <button type="button" class="btn btn-outline-danger btn-lg" id="wishlistBtn">
                            <i class="far fa-heart"></i>
                        </button>
                    </div>
                </form>
                <?php else: ?>
                    <p class="text-muted">Sản phẩm này hiện chưa có biến thể</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<section class="py-4 bg-light">
    <div class="container">
        <ul class="nav nav-tabs" id="productTab">
            <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#mota">Mô tả</a></li>
            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#danhgia">Đánh giá (<?= $ratingStats['tong_danh_gia'] ?? 0 ?>)</a></li>
        </ul>
        <div class="tab-content mt-3">
            <div class="tab-pane fade show active" id="mota">
                <div class="p-3 bg-white rounded shadow-sm">
                    <?= $product['mo_ta'] ? nl2br(htmlspecialchars($product['mo_ta'])) : 'Chưa có mô tả' ?>
                </div>
            </div>
            <div class="tab-pane fade" id="danhgia">
                <div class="row">
                    <div class="col-md-4">
                        <div class="text-center p-4 bg-white rounded shadow-sm">
                            <h2 class="text-primary fw-bold"><?= number_format($ratingStats['trung_binh_sao'] ?? 0, 1) ?></h2>
                            <div class="text-warning">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star<?= $i <= round($ratingStats['trung_binh_sao'] ?? 0) ? '' : '-o' ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <small class="text-muted"><?= $ratingStats['tong_danh_gia'] ?? 0 ?> đánh giá</small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="p-4 bg-white rounded shadow-sm">
                            <?php if (\Session::isLoggedIn()): ?>
                            <form action="<?= url('binh-luan') ?>" method="post" class="mb-4">
                                <input type="hidden" name="san_pham_id" value="<?= $product['id_san_pham'] ?>">
                                <div class="mb-2">
                                    <label class="form-label">Đánh giá của bạn:</label>
                                    <select name="so_sao" class="form-select" style="width: auto;">
                                        <?php for ($i = 5; $i >= 1; $i--): ?>
                                        <option value="<?= $i ?>"><?= $i ?> sao</option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="mb-2">
                                    <textarea name="noi_dung" class="form-control" rows="2" placeholder="Nhập nội dung đánh giá..."></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary btn-sm">Gửi đánh giá</button>
                            </form>
                            <?php endif; ?>
                            <div class="reviews">
                                <?php if (empty($reviews)): ?>
                                    <p class="text-muted">Chưa có đánh giá nào</p>
                                <?php else: ?>
                                    <?php foreach ($reviews as $review): ?>
                                    <div class="border-bottom pb-2 mb-2">
                                        <div class="d-flex justify-content-between">
                                            <strong><?= htmlspecialchars($review['ho_ten']) ?></strong>
                                            <div class="text-warning">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <i class="fas fa-star<?= $i <= $review['so_sao'] ? '' : '-o' ?>"></i>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                        <small class="text-muted"><?= date('d/m/Y', strtotime($review['ngay_tao'])) ?></small>
                                        <p class="mt-1 mb-0"><?= nl2br(htmlspecialchars($review['noi_dung'])) ?></p>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if (!empty($relatedProducts)): ?>
<section class="py-4">
    <div class="container">
        <h4 class="fw-bold mb-3">Sản phẩm liên quan</h4>
        <div class="row g-3">
            <?php foreach ($relatedProducts as $product): ?>
            <div class="col-lg-3 col-md-4 col-6">
                <div class="card border-0 shadow-sm h-100">
                    <img src="<?= $product['hinh_cover'] ? upload($product['hinh_cover']) : 'https://placehold.co/300x300/e0e0e0/666666?text=No+Image' ?>" 
                         class="card-img-top" style="height: 150px; object-fit: cover;">
                    <div class="card-body text-center">
                        <h6 class="text-truncate"><?= htmlspecialchars($product['ten_san_pham']) ?></h6>
                        <span class="text-primary fw-bold"><?= $product['gia_thap_nhat'] ? formatPrice($product['gia_thap_nhat']) : 'Liên hệ' ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<script>
$(document).ready(function() {
    $('.variant-radio').change(function() {
        var price = $(this).data('price');
        $('#displayPrice').text(formatPrice(price));
    });

    $('#qtyMinus').click(function() {
        var qty = parseInt($('#quantity').val());
        if (qty > 1) $('#quantity').val(qty - 1);
    });

    $('#qtyPlus').click(function() {
        var qty = parseInt($('#quantity').val());
        $('#quantity').val(qty + 1);
    });

    $('#addToCartBtn').click(function() {
        var variantId = $('.variant-radio:checked').val();
        var quantity = $('#quantity').val();
        $.post('<?= url('gio-hang/them') ?>', {
            bien_the_id: variantId,
            so_luong: quantity
        }, function(res) {
            if (res.success) {
                alert('Đã thêm vào giỏ hàng!');
            } else {
                alert(res.message || 'Có lỗi xảy ra');
            }
        });
    });
});
</script>
