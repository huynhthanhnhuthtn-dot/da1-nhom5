<section class="page-banner bg-primary text-white py-4">
    <div class="container">
        <h4 class="mb-1"><?= $pageTitle ?></h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>" class="text-white">Trang chủ</a></li>
                <li class="breadcrumb-item active text-white-50" aria-current="page"><?= $pageTitle ?></li>
            </ol>
        </nav>
    </div>
</section>

<section class="py-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-primary text-white fw-bold">Danh mục</div>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($categories ?? [] as $cat): ?>
                        <li class="list-group-item">
                            <a href="<?= url('san-pham?danh_muc=' . $cat['id_danh_muc']) ?>" class="text-decoration-none text-dark">
                                <?= htmlspecialchars($cat['ten_danh_muc']) ?>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <p class="mb-0">Tìm thấy <strong><?= $total ?></strong> sản phẩm</p>
                </div>
                <div class="row g-3">
                    <?php if (empty($products)): ?>
                    <div class="col-12 text-center py-5">
                        <i class="fas fa-box-open fa-4x text-muted mb-3"></i>
                        <p>Không tìm thấy sản phẩm</p>
                    </div>
                    <?php else: ?>
                        <?php foreach ($products as $product): ?>
                        <div class="col-lg-4 col-md-4 col-6">
                            <div class="card border-0 shadow-sm h-100 product-card">
                                <div class="position-relative">
                                    <img src="<?= $product['hinh_cover'] ? upload($product['hinh_cover']) : 'https://placehold.co/300x300/e0e0e0/666666?text=No+Image' ?>" 
                                         class="card-img-top" alt="<?= htmlspecialchars($product['ten_san_pham']) ?>"
                                         style="height: 180px; object-fit: cover;">
                                    <?php if (($product['thuoc_ke_don'] ?? '') === 'prescription'): ?>
                                        <span class="badge bg-warning position-absolute top-0 start-0 m-2">Kê đơn</span>
                                    <?php endif; ?>
                                </div>
                                <div class="card-body text-center">
                                    <h6 class="card-title text-truncate"><?= htmlspecialchars($product['ten_san_pham']) ?></h6>
                                    <p class="text-primary fw-bold mb-2">
                                        <?php if (isset($product['gia_thap_nhat']) && $product['gia_thap_nhat']): ?>
                                            <?= formatPrice($product['gia_thap_nhat']) ?>
                                        <?php else: ?>
                                            Liên hệ
                                        <?php endif; ?>
                                    </p>
                                    <a href="<?= url('san-pham/' . $product['id_san_pham']) ?>" class="btn btn-outline-primary btn-sm">Chi tiết</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <?php if ($totalPages > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page - 1 ?><?= isset($keyword) && $keyword ? '&keyword=' . urlencode($keyword) : '' ?>">Trước</a>
                        </li>
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?><?= isset($keyword) && $keyword ? '&keyword=' . urlencode($keyword) : '' ?>"><?= $i ?></a>
                        </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page + 1 ?><?= isset($keyword) && $keyword ? '&keyword=' . urlencode($keyword) : '' ?>">Sau</a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
