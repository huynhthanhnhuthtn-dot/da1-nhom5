<section class="page-banner bg-primary text-white py-4">
    <div class="container">
        <h4 class="mb-1">Hệ thống nhà thuốc</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>" class="text-white">Trang chủ</a></li>
                <li class="breadcrumb-item active text-white-50">Hệ thống nhà thuốc</li>
            </ol>
        </nav>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <h4 class="fw-bold mb-4">Danh sách cửa hàng</h4>
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <h5 class="fw-bold"><i class="fas fa-store text-primary me-2"></i>Nhà thuốc 5 - Quận 1</h5>
                        <p class="mb-1"><i class="fas fa-map-marker-alt me-2"></i>123 ABC, Phường Bến Nghé, Quận 1, TP.HCM</p>
                        <p class="mb-1"><i class="fas fa-phone me-2"></i>028 1234 5678</p>
                        <p class="mb-0"><i class="fas fa-clock me-2"></i>7:00 - 22:00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <h5 class="fw-bold"><i class="fas fa-store text-primary me-2"></i>Nhà thuốc 5 - Quận 3</h5>
                        <p class="mb-1"><i class="fas fa-map-marker-alt me-2"></i>456 XYZ, Phường 7, Quận 3, TP.HCM</p>
                        <p class="mb-1"><i class="fas fa-phone me-2"></i>028 2345 6789</p>
                        <p class="mb-0"><i class="fas fa-clock me-2"></i>7:00 - 22:00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <h5 class="fw-bold"><i class="fas fa-store text-primary me-2"></i>Nhà thuốc 5 - Phú Nhuận</h5>
                        <p class="mb-1"><i class="fas fa-map-marker-alt me-2"></i>789 DEF, Phường 10, Quận Phú Nhuận, TP.HCM</p>
                        <p class="mb-1"><i class="fas fa-phone me-2"></i>028 3456 7890</p>
                        <p class="mb-0"><i class="fas fa-clock me-2"></i>7:00 - 22:00</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <h5 class="fw-bold"><i class="fas fa-store text-primary me-2"></i>Nhà thuốc 5 - Tân Bình</h5>
                        <p class="mb-1"><i class="fas fa-map-marker-alt me-2"></i>321 GHI, Phường 12, Quận Tân Bình, TP.HCM</p>
                        <p class="mb-1"><i class="fas fa-phone me-2"></i>028 4567 8901</p>
                        <p class="mb-0"><i class="fas fa-clock me-2"></i>7:00 - 22:00</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
