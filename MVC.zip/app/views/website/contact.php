<section class="page-banner bg-primary text-white py-4">
    <div class="container">
        <h4 class="mb-1">Liên hệ</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>" class="text-white">Trang chủ</a></li>
                <li class="breadcrumb-item active text-white-50">Liên hệ</li>
            </ol>
        </nav>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-6">
                <h4 class="fw-bold mb-3">Thông tin liên hệ</h4>
                <div class="mb-3">
                    <p><i class="fas fa-map-marker-alt text-primary me-2"></i> 123 Đường ABC, Quận 1, TP. Hồ Chí Minh</p>
                    <p><i class="fas fa-phone text-primary me-2"></i> Hotline: 1900 1234</p>
                    <p><i class="fas fa-envelope text-primary me-2"></i> Email: info@nhathuoc5.vn</p>
                    <p><i class="fas fa-clock text-primary me-2"></i> Giờ làm việc: 7:00 - 22:00 hàng ngày</p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3">Gửi tin nhắn cho chúng tôi</h5>
                        <form>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <input type="text" class="form-control" placeholder="Họ tên">
                                </div>
                                <div class="col-md-6">
                                    <input type="email" class="form-control" placeholder="Email">
                                </div>
                                <div class="col-12">
                                    <input type="text" class="form-control" placeholder="Tiêu đề">
                                </div>
                                <div class="col-12">
                                    <textarea class="form-control" rows="4" placeholder="Nội dung"></textarea>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">Gửi tin nhắn</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
