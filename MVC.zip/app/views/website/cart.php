<section class="page-banner bg-primary text-white py-4">
    <div class="container">
        <h4 class="mb-1">Giỏ hàng</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>" class="text-white">Trang chủ</a></li>
                <li class="breadcrumb-item active text-white-50">Giỏ hàng</li>
            </ol>
        </nav>
    </div>
</section>

<section class="py-4">
    <div class="container">
        <?php if (empty($items)): ?>
        <div class="text-center py-5">
            <i class="fas fa-shopping-cart fa-5x text-muted mb-3"></i>
            <h5>Giỏ hàng trống</h5>
            <p class="text-muted">Hãy thêm sản phẩm vào giỏ hàng</p>
            <a href="<?= url('san-pham') ?>" class="btn btn-primary">Mua hàng ngay</a>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-primary">
                    <tr>
                        <th>Sản phẩm</th>
                        <th>Phân loại</th>
                        <th>Đơn giá</th>
                        <th width="120">Số lượng</th>
                        <th>Thành tiền</th>
                        <th width="50"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <img src="<?= $item['hinh_anh_bien_the'] ? upload($item['hinh_anh_bien_the']) : ($item['hinh_cover'] ? upload($item['hinh_cover']) : 'https://placehold.co/60x60') ?>" 
                                     style="width: 60px; height: 60px; object-fit: cover;" class="rounded">
                                <span><?= htmlspecialchars($item['ten_san_pham']) ?></span>
                            </div>
                        </td>
                        <td><?= htmlspecialchars($item['ten_bien_the']) ?></td>
                        <td><?= formatPrice($item['gia_ban']) ?></td>
                        <td>
                            <div class="input-group input-group-sm">
                                <button class="btn btn-outline-secondary qty-update" data-id="<?= $item['id_chi_tiet_gio_hang'] ?>" data-action="minus">-</button>
                                <input type="text" class="form-control text-center qty-input" value="<?= $item['so_luong'] ?>" readonly>
                                <button class="btn btn-outline-secondary qty-update" data-id="<?= $item['id_chi_tiet_gio_hang'] ?>" data-action="plus">+</button>
                            </div>
                        </td>
                        <td class="fw-bold text-primary"><?= formatPrice($item['gia_ban'] * $item['so_luong']) ?></td>
                        <td>
                            <button class="btn btn-danger btn-sm remove-item" data-id="<?= $item['id_chi_tiet_gio_hang'] ?>">
                                <i class="fas fa-times"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4" class="text-end fw-bold">Tổng cộng:</td>
                        <td colspan="2" class="text-primary fw-bold h5"><?= formatPrice($total) ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="d-flex justify-content-between mt-3">
            <a href="<?= url('san-pham') ?>" class="btn btn-outline-primary"><i class="fas fa-arrow-left me-2"></i>Tiếp tục mua hàng</a>
            <a href="<?= url('thanh-toan') ?>" class="btn btn-primary btn-lg"><i class="fas fa-credit-card me-2"></i>Tiến hành thanh toán</a>
        </div>
        <?php endif; ?>
    </div>
</section>

<script>
$(document).ready(function() {
    $('.qty-update').click(function() {
        var id = $(this).data('id');
        var action = $(this).data('action');
        var input = $(this).closest('.input-group').find('.qty-input');
        var qty = parseInt(input.val());
        qty = action === 'plus' ? qty + 1 : qty - 1;
        if (qty < 1) {
            if (confirm('Xóa sản phẩm này?')) {
                $.post('<?= url('gio-hang/xoa') ?>', {id: id}, function() { location.reload(); });
            }
            return;
        }
        $.post('<?= url('gio-hang/cap-nhat') ?>', {id: id, so_luong: qty}, function() { location.reload(); });
    });

    $('.remove-item').click(function() {
        if (confirm('Xóa sản phẩm này khỏi giỏ hàng?')) {
            var id = $(this).data('id');
            $.post('<?= url('gio-hang/xoa') ?>', {id: id}, function() { location.reload(); });
        }
    });
});
</script>
