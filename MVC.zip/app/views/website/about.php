<section class="page-banner bg-primary text-white py-4">
    <div class="container">
        <h4 class="mb-1">Giới thiệu</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>" class="text-white">Trang chủ</a></li>
                <li class="breadcrumb-item active text-white-50">Giới thiệu</li>
            </ol>
        </nav>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row align-items-center g-4">
            <div class="col-lg-6">
                <h3 class="fw-bold mb-3">Về <?= SITE_NAME ?></h3>
                <p><?= SITE_NAME ?> là hệ thống nhà thuốc lớn số 1 Việt Nam, với hơn 30 năm kinh nghiệm trong lĩnh vực dược phẩm và chăm sóc sức khỏe.</p>
                <p>Chúng tôi cam kết cung cấp các sản phẩm thuốc chính hãng, chất lượng cao với giá cả cạnh tranh nhất thị trường. Đội ngũ dược sĩ giàu kinh nghiệm luôn sẵn sàng tư vấn và hỗ trợ khách hàng 24/7.</p>
                <div class="row g-3 mt-3">
                    <div class="col-6">
                        <div class="card border-0 bg-light p-3 text-center">
                            <h4 class="text-primary fw-bold mb-0">30+</h4>
                            <small>Năm kinh nghiệm</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card border-0 bg-light p-3 text-center">
                            <h4 class="text-primary fw-bold mb-0">1000+</h4>
                            <small>Sản phẩm</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card border-0 bg-light p-3 text-center">
                            <h4 class="text-primary fw-bold mb-0">50000+</h4>
                            <small>Khách hàng</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card border-0 bg-light p-3 text-center">
                            <h4 class="text-primary fw-bold mb-0">100+</h4>
                            <small>Chi nhánh</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 text-center">
                <i class="fas fa-clinic-medical text-primary" style="font-size: 200px; opacity: 0.3;"></i>
            </div>
        </div>
    </div>
</section>
