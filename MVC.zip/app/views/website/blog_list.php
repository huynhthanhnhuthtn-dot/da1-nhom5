<section class="page-banner bg-primary text-white py-4">
    <div class="container">
        <h4 class="mb-1">Góc sức khỏe</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>" class="text-white">Trang chủ</a></li>
                <li class="breadcrumb-item active text-white-50">Góc sức khỏe</li>
            </ol>
        </nav>
    </div>
</section>

<section class="py-4">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="row g-4">
                    <?php if (empty($posts)): ?>
                    <div class="col-12 text-center py-5">
                        <p>Chưa có bài viết nào</p>
                    </div>
                    <?php else: ?>
                        <?php foreach ($posts as $post): ?>
                        <div class="col-md-6">
                            <div class="card border-0 shadow-sm h-100">
                                <img src="<?= $post['hinh_anh_dai_dien'] ? upload($post['hinh_anh_dai_dien']) : 'https://placehold.co/600x400/e0e0e0/666666?text=News' ?>" 
                                     class="card-img-top" style="height: 200px; object-fit: cover;">
                                <div class="card-body">
                                    <small class="text-muted"><i class="far fa-calendar me-1"></i><?= date('d/m/Y', strtotime($post['ngay_tao'])) ?></small>
                                    <h5 class="mt-2"><?= htmlspecialchars($post['tieu_de']) ?></h5>
                                    <p class="text-muted"><?= htmlspecialchars(truncateText($post['tom_tat'], 120)) ?></p>
                                    <a href="<?= url('tin-tuc/' . $post['slug']) ?>" class="btn btn-outline-primary btn-sm">Đọc tiếp</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <?php if ($totalPages > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page - 1 ?>">Trước</a>
                        </li>
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                        </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page + 1 ?>">Sau</a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-primary text-white fw-bold">Danh mục</div>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($categories as $cat): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <a href="?danh_muc=<?= $cat['id_danh_muc_tin'] ?>" class="text-decoration-none text-dark">
                                <?= htmlspecialchars($cat['ten_danh_muc']) ?>
                            </a>
                            <span class="badge bg-primary rounded-pill"><?= $cat['so_luong_bai'] ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
