<section class="page-banner bg-primary text-white py-4">
    <div class="container">
        <h4 class="mb-1">Thanh toán</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>" class="text-white">Trang chủ</a></li>
                <li class="breadcrumb-item"><a href="<?= url('gio-hang') ?>" class="text-white">Giỏ hàng</a></li>
                <li class="breadcrumb-item active text-white-50">Thanh toán</li>
            </ol>
        </nav>
    </div>
</section>

<section class="py-4">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white fw-bold">Thông tin giao hàng</div>
                    <div class="card-body">
                        <form id="checkoutForm">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Người nhận <span class="text-danger">*</span></label>
                                    <input type="text" name="nguoi_nhan" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Số điện thoại <span class="text-danger">*</span></label>
                                    <input type="text" name="so_dien_thoai" class="form-control" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Địa chỉ giao hàng <span class="text-danger">*</span></label>
                                    <textarea name="dia_chi_giao_hang" class="form-control" rows="2" required></textarea>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white fw-bold">Đơn hàng</div>
                    <div class="card-body">
                        <?php foreach ($items as $item): ?>
                        <div class="d-flex justify-content-between mb-2">
                            <span><small><?= htmlspecialchars($item['ten_san_pham']) ?> x<?= $item['so_luong'] ?></small></span>
                            <span class="fw-bold"><?= formatPrice($item['gia_ban'] * $item['so_luong']) ?></span>
                        </div>
                        <?php endforeach; ?>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <span>Tạm tính:</span>
                            <span><?= formatPrice($total) ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Phí vận chuyển:</span>
                            <span class="text-success">Miễn phí</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <strong>Tổng cộng:</strong>
                            <strong class="text-primary h5"><?= formatPrice($total) ?></strong>
                        </div>
                        <button type="button" class="btn btn-primary w-100 mt-3 btn-lg" id="placeOrderBtn">
                            <i class="fas fa-check me-2"></i>Đặt hàng
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
$(document).ready(function() {
    $('#placeOrderBtn').click(function() {
        var data = $('#checkoutForm').serialize();
        $.post('<?= url('thanh-toan/dat-hang') ?>', data, function(res) {
            if (res.success) {
                window.location.href = res.redirect;
            } else {
                alert(res.message || 'Đặt hàng thất bại');
            }
        });
    });
});
</script>
