<section class="py-5">
    <div class="container text-center">
        <div class="card border-0 shadow-sm mx-auto" style="max-width: 600px;">
            <div class="card-body py-5">
                <i class="fas fa-check-circle text-success fa-5x mb-3"></i>
                <h3 class="fw-bold">Đặt hàng thành công!</h3>
                <p class="text-muted">Cảm ơn bạn đã mua hàng. Đơn hàng của bạn đã được ghi nhận.</p>
                <div class="bg-light p-3 rounded mb-3 text-start">
                    <p class="mb-1"><strong>Mã đơn hàng:</strong> <?= htmlspecialchars($order['ma_don_hang']) ?></p>
                    <p class="mb-1"><strong>Người nhận:</strong> <?= htmlspecialchars($order['nguoi_nhan']) ?></p>
                    <p class="mb-1"><strong>Địa chỉ:</strong> <?= htmlspecialchars($order['dia_chi_giao_hang']) ?></p>
                    <p class="mb-0"><strong>Tổng tiền:</strong> <span class="text-primary fw-bold"><?= formatPrice($order['thanh_tien']) ?></span></p>
                </div>
                <a href="<?= BASE_URL ?>" class="btn btn-primary">Về trang chủ</a>
            </div>
        </div>
    </div>
</section>
