<section class="page-banner bg-primary text-white py-4">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>" class="text-white">Trang chủ</a></li>
                <li class="breadcrumb-item"><a href="<?= url('tin-tuc') ?>" class="text-white">Góc sức khỏe</a></li>
                <li class="breadcrumb-item active text-white-50"><?= htmlspecialchars($post['tieu_de']) ?></li>
            </ol>
        </nav>
    </div>
</section>

<section class="py-4">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-8">
                <article class="card border-0 shadow-sm">
                    <img src="<?= $post['hinh_anh_dai_dien'] ? upload($post['hinh_anh_dai_dien']) : 'https://placehold.co/800x400/e0e0e0/666666?text=News' ?>" 
                         class="card-img-top" style="height: 400px; object-fit: cover;">
                    <div class="card-body p-4">
                        <h3 class="fw-bold"><?= htmlspecialchars($post['tieu_de']) ?></h3>
                        <div class="text-muted mb-3">
                            <small><i class="far fa-user me-1"></i><?= htmlspecialchars($post['nguoi_viet']) ?></small>
                            <small class="ms-3"><i class="far fa-calendar me-1"></i><?= date('d/m/Y', strtotime($post['ngay_tao'])) ?></small>
                            <small class="ms-3"><i class="far fa-eye me-1"></i><?= $post['luot_xem'] ?> lượt xem</small>
                        </div>
                        <div class="post-content">
                            <?= $post['noi_dung'] ?>
                        </div>
                    </div>
                </article>
            </div>
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-primary text-white fw-bold">Danh mục</div>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($categories as $cat): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <a href="<?= url('tin-tuc?danh_muc=' . $cat['id_danh_muc_tin']) ?>" class="text-decoration-none text-dark">
                                <?= htmlspecialchars($cat['ten_danh_muc']) ?>
                            </a>
                            <span class="badge bg-primary rounded-pill"><?= $cat['so_luong_bai'] ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <?php if (!empty($latestPosts)): ?>
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white fw-bold">Bài viết mới</div>
                    <div class="card-body">
                        <?php foreach ($latestPosts as $lp): ?>
                        <div class="d-flex gap-2 mb-3">
                            <img src="<?= $lp['hinh_anh_dai_dien'] ? upload($lp['hinh_anh_dai_dien']) : 'https://placehold.co/80x80/e0e0e0/666666?text=N' ?>" 
                                 style="width: 80px; height: 80px; object-fit: cover;" class="rounded">
                            <div>
                                <a href="<?= url('tin-tuc/' . $lp['slug']) ?>" class="text-decoration-none text-dark">
                                    <small><strong><?= htmlspecialchars(truncateText($lp['tieu_de'], 50)) ?></strong></small>
                                </a>
                                <br>
                                <small class="text-muted"><?= date('d/m/Y', strtotime($lp['ngay_tao'])) ?></small>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
