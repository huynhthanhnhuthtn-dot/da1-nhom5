<section class="hero-section bg-primary text-white py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h2 class="fw-bold mb-3">Hệ thống nhà thuốc lớn số 1 Việt Nam</h2>
                <p class="lead mb-4">Sức khỏe của bạn là ưu tiên hàng đầu của chúng tôi. Với hơn 30 năm kinh nghiệm, chúng tôi cam kết mang đến sản phẩm chính hãng, chất lượng.</p>
                <div class="d-flex gap-3">
                    <a href="<?= url('san-pham') ?>" class="btn btn-light btn-lg px-4">Mua hàng ngay</a>
                    <a href="<?= url('ke-toa') ?>" class="btn btn-outline-light btn-lg px-4">Gửi đơn thuốc</a>
                </div>
            </div>
            <div class="col-lg-6 text-center mt-4 mt-lg-0">
                <i class="fas fa-prescription-bottle-alt" style="font-size: 180px; opacity: 0.3;"></i>
            </div>
        </div>
    </div>
</section>

<section class="features py-4 bg-light">
    <div class="container">
        <div class="row text-center g-3">
            <div class="col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <i class="fas fa-trophy text-primary fa-3x mb-3"></i>
                        <h6>Uy tín hơn 30 năm</h6>
                        <small class="text-muted">Thương hiệu từ năm 1988</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <i class="fas fa-shield-alt text-primary fa-3x mb-3"></i>
                        <h6>Thuốc chính hãng 100%</h6>
                        <small class="text-muted">Cam kết nguồn gốc rõ ràng</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <i class="fas fa-user-md text-primary fa-3x mb-3"></i>
                        <h6>Dược sĩ tư vấn</h6>
                        <small class="text-muted">Đội ngũ dược sĩ giỏi</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <i class="fas fa-truck text-primary fa-3x mb-3"></i>
                        <h6>Giao hàng toàn quốc</h6>
                        <small class="text-muted">Miễn phí giao hàng đơn >500k</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="categories py-5">
    <div class="container">
        <h3 class="text-center mb-4 fw-bold">Danh mục sản phẩm</h3>
        <div class="row g-3">
            <?php foreach ($categories as $cat): ?>
            <div class="col-lg-3 col-md-4 col-6">
                <a href="<?= url('san-pham?danh_muc=' . $cat['id_danh_muc']) ?>" class="text-decoration-none">
                    <div class="card border-0 shadow-sm text-center h-100">
                        <div class="card-body py-4">
                            <i class="fas fa-pills text-primary fa-3x mb-3"></i>
                            <h6 class="text-dark"><?= htmlspecialchars($cat['ten_danh_muc']) ?></h6>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="featured-products py-5 bg-light">
    <div class="container">
        <h3 class="text-center mb-4 fw-bold">Sản phẩm nổi bật</h3>
        <div class="row g-3">
            <?php foreach ($featuredProducts as $product): ?>
            <div class="col-lg-3 col-md-4 col-6">
                <div class="card border-0 shadow-sm h-100 product-card">
                    <div class="position-relative">
                        <img src="<?= $product['hinh_cover'] ? upload($product['hinh_cover']) : 'https://placehold.co/300x300/e0e0e0/666666?text=No+Image' ?>" 
                             class="card-img-top" alt="<?= htmlspecialchars($product['ten_san_pham']) ?>"
                             style="height: 200px; object-fit: cover;">
                        <?php if ($product['thuoc_ke_don'] === 'prescription'): ?>
                            <span class="badge bg-warning position-absolute top-0 start-0 m-2">Kê đơn</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body text-center">
                        <h6 class="card-title text-truncate"><?= htmlspecialchars($product['ten_san_pham']) ?></h6>
                        <p class="text-primary fw-bold mb-2">
                            <?php if ($product['gia_thap_nhat']): ?>
                                <?= formatPrice($product['gia_thap_nhat']) ?> - <?= formatPrice($product['gia_cao_nhat']) ?>
                            <?php else: ?>
                                Liên hệ
                            <?php endif; ?>
                        </p>
                        <a href="<?= url('san-pham/' . $product['id_san_pham']) ?>" class="btn btn-outline-primary btn-sm">Xem chi tiết</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-4">
            <a href="<?= url('san-pham') ?>" class="btn btn-primary px-4">Xem tất cả sản phẩm</a>
        </div>
    </div>
</section>

<?php if (!empty($latestPosts)): ?>
<section class="latest-news py-5">
    <div class="container">
        <h3 class="text-center mb-4 fw-bold">Góc sức khỏe</h3>
        <div class="row g-4">
            <?php foreach ($latestPosts as $post): ?>
            <div class="col-lg-4 col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <img src="<?= $post['hinh_anh_dai_dien'] ? upload($post['hinh_anh_dai_dien']) : 'https://placehold.co/600x400/e0e0e0/666666?text=News' ?>" 
                         class="card-img-top" alt="<?= htmlspecialchars($post['tieu_de']) ?>"
                         style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <small class="text-muted"><i class="far fa-calendar me-1"></i><?= date('d/m/Y', strtotime($post['ngay_tao'])) ?></small>
                        <h6 class="mt-2"><?= htmlspecialchars($post['tieu_de']) ?></h6>
                        <p class="text-muted small"><?= htmlspecialchars(truncateText($post['tom_tat'], 100)) ?></p>
                        <a href="<?= url('tin-tuc/' . $post['slug']) ?>" class="btn btn-link text-primary p-0">Đọc tiếp →</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>
