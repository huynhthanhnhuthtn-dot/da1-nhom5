<?php
class Blog extends Model
{
    protected $table = 'tin_tuc';

    public function getWithCategory($id)
    {
        $sql = "SELECT t.*, dm.ten_danh_muc as ten_danh_muc_tin, nd.ho_ten as nguoi_viet
                FROM {$this->table} t
                LEFT JOIN danh_muc_tin_tuc dm ON t.danh_muc_tin_id = dm.id_danh_muc_tin
                LEFT JOIN nguoi_dung nd ON t.nguoi_viet_id = nd.id_nguoi_dung
                WHERE t.id_tin_tuc = ?";
        return $this->db->fetchOne($sql, [$id]);
    }

    public function getBySlug($slug)
    {
        $sql = "SELECT t.*, dm.ten_danh_muc as ten_danh_muc_tin, nd.ho_ten as nguoi_viet
                FROM {$this->table} t
                LEFT JOIN danh_muc_tin_tuc dm ON t.danh_muc_tin_id = dm.id_danh_muc_tin
                LEFT JOIN nguoi_dung nd ON t.nguoi_viet_id = nd.id_nguoi_dung
                WHERE t.slug = ? AND t.trang_thai = 'active'";
        return $this->db->fetchOne($sql, [$slug]);
    }

    public function getPublished($page = 1, $perPage = 6)
    {
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT t.*, dm.ten_danh_muc as ten_danh_muc_tin, nd.ho_ten as nguoi_viet
                FROM {$this->table} t
                LEFT JOIN danh_muc_tin_tuc dm ON t.danh_muc_tin_id = dm.id_danh_muc_tin
                LEFT JOIN nguoi_dung nd ON t.nguoi_viet_id = nd.id_nguoi_dung
                WHERE t.trang_thai = 'active'
                ORDER BY t.ngay_tao DESC
                LIMIT $perPage OFFSET $offset";
        $items = $this->db->fetchAll($sql);

        $countSql = "SELECT COUNT(*) as total FROM {$this->table} WHERE trang_thai = 'active'";
        $total = $this->db->fetchOne($countSql)['total'];

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'totalPages' => ceil($total / $perPage),
        ];
    }

    public function getByCategory($categoryId, $page = 1, $perPage = 6)
    {
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT t.*, dm.ten_danh_muc as ten_danh_muc_tin, nd.ho_ten as nguoi_viet
                FROM {$this->table} t
                LEFT JOIN danh_muc_tin_tuc dm ON t.danh_muc_tin_id = dm.id_danh_muc_tin
                LEFT JOIN nguoi_dung nd ON t.nguoi_viet_id = nd.id_nguoi_dung
                WHERE t.danh_muc_tin_id = ? AND t.trang_thai = 'active'
                ORDER BY t.ngay_tao DESC
                LIMIT $perPage OFFSET $offset";
        $items = $this->db->fetchAll($sql, [$categoryId]);

        $countSql = "SELECT COUNT(*) as total FROM {$this->table} WHERE danh_muc_tin_id = ? AND trang_thai = 'active'";
        $total = $this->db->fetchOne($countSql, [$categoryId])['total'];

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'totalPages' => ceil($total / $perPage),
        ];
    }

    public function incrementViews($id)
    {
        $sql = "UPDATE {$this->table} SET luot_xem = luot_xem + 1 WHERE id_tin_tuc = ?";
        return $this->db->query($sql, [$id]);
    }

    public function getLatest($limit = 3)
    {
        $sql = "SELECT t.*, dm.ten_danh_muc as ten_danh_muc_tin
                FROM {$this->table} t
                LEFT JOIN danh_muc_tin_tuc dm ON t.danh_muc_tin_id = dm.id_danh_muc_tin
                WHERE t.trang_thai = 'active'
                ORDER BY t.ngay_tao DESC
                LIMIT $limit";
        return $this->db->fetchAll($sql);
    }
}
