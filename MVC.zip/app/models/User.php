<?php
class User extends Model
{
    protected $table = 'nguoi_dung';

    public function __construct()
    {
        parent::__construct();
    }

    public function getByUsername($username)
    {
        $sql = "SELECT * FROM {$this->table} WHERE ten_user = ?";
        return $this->db->fetchOne($sql, [$username]);
    }

    public function getByEmail($email)
    {
        $sql = "SELECT * FROM {$this->table} WHERE email = ?";
        return $this->db->fetchOne($sql, [$email]);
    }

    public function login($username, $password)
    {
        $user = $this->getByUsername($username);
        if ($user && password_verify($password, $user['mat_khau'])) {
            return $user;
        }
        return false;
    }

    public function register($data)
    {
        $data['mat_khau'] = password_hash($data['mat_khau'], PASSWORD_DEFAULT);
        $data['vai_tro'] = 'customer';
        $data['trang_thai'] = 'active';
        return $this->create($data);
    }

    public function getCountByRole($role)
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE vai_tro = ?";
        $result = $this->db->fetchOne($sql, [$role]);
        return $result['total'];
    }
}
