<?php
class Order extends Model
{
    protected $table = 'don_hang';

    public function getWithDetails($id)
    {
        $sql = "SELECT dh.*, nd.ho_ten as ten_khach, nd.email, nd.so_dien_thoai as sdt_khach
                FROM {$this->table} dh
                LEFT JOIN nguoi_dung nd ON dh.nguoi_dung_id = nd.id_nguoi_dung
                WHERE dh.id_don_hang = ?";
        return $this->db->fetchOne($sql, [$id]);
    }

    public function getItems($orderId)
    {
        $sql = "SELECT ct.*, bt.ten_bien_the, bt.don_vi_tinh, bt.hinh_anh_bien_the,
                       sp.ten_san_pham
                FROM chi_tiet_don_hang ct
                JOIN bien_the_san_pham bt ON ct.bien_the_id = bt.id_bien_the
                JOIN san_pham sp ON bt.san_pham_id = sp.id_san_pham
                WHERE ct.don_hang_id = ?";
        return $this->db->fetchAll($sql, [$orderId]);
    }

    public function getByUserId($userId, $page = 1, $perPage = 10)
    {
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT * FROM {$this->table} WHERE nguoi_dung_id = ? ORDER BY ngay_dat DESC LIMIT $perPage OFFSET $offset";
        $items = $this->db->fetchAll($sql, [$userId]);

        $countSql = "SELECT COUNT(*) as total FROM {$this->table} WHERE nguoi_dung_id = ?";
        $total = $this->db->fetchOne($countSql, [$userId])['total'];

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'totalPages' => ceil($total / $perPage),
        ];
    }

    public function createOrder($data)
    {
        return $this->create($data);
    }

    public function generateOrderCode()
    {
        $prefix = 'DH';
        $date = date('Ymd');
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE DATE(ngay_dat) = CURDATE()";
        $result = $this->db->fetchOne($sql);
        $count = $result['total'] + 1;
        return $prefix . $date . str_pad($count, 4, '0', STR_PAD_LEFT);
    }

    public function getRevenueByDate($from, $to)
    {
        $sql = "SELECT DATE(ngay_dat) as ngay, SUM(thanh_tien) as doanh_thu, COUNT(*) as so_don
                FROM {$this->table}
                WHERE trang_thai_don_hang = 'completed'
                AND DATE(ngay_dat) BETWEEN ? AND ?
                GROUP BY DATE(ngay_dat)
                ORDER BY ngay";
        return $this->db->fetchAll($sql, [$from, $to]);
    }

    public function getStats()
    {
        $today = date('Y-m-d');
        $sql = "SELECT
                    COUNT(*) as tong_don,
                    SUM(CASE WHEN DATE(ngay_dat) = ? THEN 1 ELSE 0 END) as don_hom_nay,
                    SUM(CASE WHEN trang_thai_don_hang = 'pending' THEN 1 ELSE 0 END) as don_cho_xu_ly,
                    COALESCE(SUM(thanh_tien), 0) as tong_doanh_thu
                FROM {$this->table}";
        return $this->db->fetchOne($sql, [$today]);
    }
}
