<?php
class Cart extends Model
{
    protected $table = 'gio_hang';

    public function getByUserId($userId)
    {
        $sql = "SELECT * FROM {$this->table} WHERE nguoi_dung_id = ?";
        return $this->db->fetchOne($sql, [$userId]);
    }

    public function getOrCreate($userId)
    {
        $cart = $this->getByUserId($userId);
        if (!$cart) {
            $cartId = $this->create([
                'nguoi_dung_id' => $userId,
                'ngay_tao' => date('Y-m-d H:i:s'),
                'ngay_cap_nhat' => date('Y-m-d H:i:s'),
            ]);
            return ['id_gio_hang' => $cartId];
        }
        return $cart;
    }

    public function getItems($cartId)
    {
        $sql = "SELECT ct.*, bt.ten_bien_the, bt.gia_ban, bt.don_vi_tinh, bt.hinh_anh_bien_the,
                       bt.san_pham_id, sp.ten_san_pham, sp.hinh_cover
                FROM chi_tiet_gio_hang ct
                JOIN bien_the_san_pham bt ON ct.bien_the_id = bt.id_bien_the
                JOIN san_pham sp ON bt.san_pham_id = sp.id_san_pham
                WHERE ct.gio_hang_id = ?";
        return $this->db->fetchAll($sql, [$cartId]);
    }

    public function addItem($cartId, $variantId, $quantity)
    {
        $sql = "SELECT * FROM chi_tiet_gio_hang WHERE gio_hang_id = ? AND bien_the_id = ?";
        $existing = $this->db->fetchOne($sql, [$cartId, $variantId]);

        if ($existing) {
            $newQty = $existing['so_luong'] + $quantity;
            $sql = "UPDATE chi_tiet_gio_hang SET so_luong = ? WHERE id_chi_tiet_gio_hang = ?";
            return $this->db->query($sql, [$newQty, $existing['id_chi_tiet_gio_hang']]);
        } else {
            $sql = "INSERT INTO chi_tiet_gio_hang (gio_hang_id, bien_the_id, so_luong) VALUES (?, ?, ?)";
            return $this->db->query($sql, [$cartId, $variantId, $quantity]);
        }
    }

    public function updateItem($itemId, $quantity)
    {
        $sql = "UPDATE chi_tiet_gio_hang SET so_luong = ? WHERE id_chi_tiet_gio_hang = ?";
        return $this->db->query($sql, [$quantity, $itemId]);
    }

    public function removeItem($itemId)
    {
        $sql = "DELETE FROM chi_tiet_gio_hang WHERE id_chi_tiet_gio_hang = ?";
        return $this->db->query($sql, [$itemId]);
    }

    public function getTotal($cartId)
    {
        $sql = "SELECT SUM(ct.so_luong * bt.gia_ban) as total
                FROM chi_tiet_gio_hang ct
                JOIN bien_the_san_pham bt ON ct.bien_the_id = bt.id_bien_the
                WHERE ct.gio_hang_id = ?";
        $result = $this->db->fetchOne($sql, [$cartId]);
        return $result['total'] ?? 0;
    }
}
