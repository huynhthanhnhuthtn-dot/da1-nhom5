<?php
class Wishlist extends Model
{
    protected $table = 'san_pham_yeu_thich';

    public function getByUserId($userId)
    {
        $sql = "SELECT w.*, sp.ten_san_pham, sp.hinh_cover,
                       MIN(bt.gia_ban) as gia_thap_nhat
                FROM {$this->table} w
                JOIN san_pham sp ON w.san_pham_id = sp.id_san_pham
                LEFT JOIN bien_the_san_pham bt ON sp.id_san_pham = bt.san_pham_id
                WHERE w.nguoi_dung_id = ?
                GROUP BY w.id_yeu_thich
                ORDER BY w.ngay_them DESC";
        return $this->db->fetchAll($sql, [$userId]);
    }

    public function check($userId, $productId)
    {
        $sql = "SELECT * FROM {$this->table} WHERE nguoi_dung_id = ? AND san_pham_id = ?";
        return $this->db->fetchOne($sql, [$userId, $productId]);
    }

    public function toggle($userId, $productId)
    {
        $existing = $this->check($userId, $productId);
        if ($existing) {
            $this->delete($existing['id_yeu_thich']);
            return false;
        } else {
            $this->create([
                'nguoi_dung_id' => $userId,
                'san_pham_id' => $productId,
                'ngay_them' => date('Y-m-d H:i:s'),
            ]);
            return true;
        }
    }
}
