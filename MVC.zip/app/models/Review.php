<?php
class Review extends Model
{
    protected $table = 'danh_gia_binh_luan_san_pham';

    public function getByProduct($productId)
    {
        $sql = "SELECT r.*, nd.ho_ten
                FROM {$this->table} r
                JOIN nguoi_dung nd ON r.nguoi_dung_id = nd.id_nguoi_dung
                WHERE r.san_pham_id = ? AND r.trang_thai = 'active'
                ORDER BY r.ngay_tao DESC";
        return $this->db->fetchAll($sql, [$productId]);
    }

    public function getRatingStats($productId)
    {
        $sql = "SELECT
                    COUNT(*) as tong_danh_gia,
                    AVG(so_sao) as trung_binh_sao,
                    SUM(CASE WHEN so_sao = 5 THEN 1 ELSE 0 END) as sao_5,
                    SUM(CASE WHEN so_sao = 4 THEN 1 ELSE 0 END) as sao_4,
                    SUM(CASE WHEN so_sao = 3 THEN 1 ELSE 0 END) as sao_3,
                    SUM(CASE WHEN so_sao = 2 THEN 1 ELSE 0 END) as sao_2,
                    SUM(CASE WHEN so_sao = 1 THEN 1 ELSE 0 END) as sao_1
                FROM {$this->table}
                WHERE san_pham_id = ? AND trang_thai = 'active'";
        return $this->db->fetchOne($sql, [$productId]);
    }
}
