<?php
class Category extends Model
{
    protected $table = 'danh_muc_san_pham';

    public function getWithProductCount()
    {
        $sql = "SELECT c.*, COUNT(p.id_san_pham) as so_luong_san_pham
                FROM {$this->table} c
                LEFT JOIN san_pham p ON c.id_danh_muc = p.danh_muc_id
                GROUP BY c.id_danh_muc
                ORDER BY c.ten_danh_muc";
        return $this->db->fetchAll($sql);
    }

    public function getActiveWithProducts()
    {
        $sql = "SELECT DISTINCT c.* FROM {$this->table} c
                INNER JOIN san_pham p ON c.id_danh_muc = p.danh_muc_id
                WHERE p.trang_thai = 'active'
                ORDER BY c.ten_danh_muc";
        return $this->db->fetchAll($sql);
    }
}
