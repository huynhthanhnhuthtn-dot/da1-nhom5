<?php
class Brand extends Model
{
    protected $table = 'thuong_hieu';

    public function getWithProductCount()
    {
        $sql = "SELECT b.*, COUNT(p.id_san_pham) as so_luong_san_pham
                FROM {$this->table} b
                LEFT JOIN san_pham p ON b.id_thuong_hieu = p.thuong_hieu_id
                GROUP BY b.id_thuong_hieu
                ORDER BY b.ten_thuong_hieu";
        return $this->db->fetchAll($sql);
    }
}
