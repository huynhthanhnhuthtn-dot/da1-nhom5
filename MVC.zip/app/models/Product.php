<?php
class Product extends Model
{
    protected $table = 'san_pham';

    public function getWithDetails($id)
    {
        $sql = "SELECT p.*, c.ten_danh_muc, b.ten_thuong_hieu
                FROM {$this->table} p
                LEFT JOIN danh_muc_san_pham c ON p.danh_muc_id = c.id_danh_muc
                LEFT JOIN thuong_hieu b ON p.thuong_hieu_id = b.id_thuong_hieu
                WHERE p.id_san_pham = ?";
        return $this->db->fetchOne($sql, [$id]);
    }

    public function getBySlug($slug)
    {
        $sql = "SELECT p.*, c.ten_danh_muc, b.ten_thuong_hieu
                FROM {$this->table} p
                LEFT JOIN danh_muc_san_pham c ON p.danh_muc_id = c.id_danh_muc
                LEFT JOIN thuong_hieu b ON p.thuong_hieu_id = b.id_thuong_hieu
                WHERE p.trang_thai = 'active' AND (1=1) ORDER BY p.id_san_pham DESC LIMIT 1";
        return $this->db->fetchOne($sql, [$slug]);
    }

    public function getVariants($productId)
    {
        $sql = "SELECT * FROM bien_the_san_pham WHERE san_pham_id = ?";
        return $this->db->fetchAll($sql, [$productId]);
    }

    public function getByCategory($categoryId, $page = 1, $perPage = 12)
    {
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT p.*, MIN(bt.gia_ban) as gia_thap_nhat, MAX(bt.gia_ban) as gia_cao_nhat
                FROM {$this->table} p
                LEFT JOIN bien_the_san_pham bt ON p.id_san_pham = bt.san_pham_id
                WHERE p.danh_muc_id = ? AND p.trang_thai = 'active'
                GROUP BY p.id_san_pham
                LIMIT $perPage OFFSET $offset";
        $items = $this->db->fetchAll($sql, [$categoryId]);

        $countSql = "SELECT COUNT(*) as total FROM {$this->table} WHERE danh_muc_id = ? AND trang_thai = 'active'";
        $total = $this->db->fetchOne($countSql, [$categoryId])['total'];

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'totalPages' => ceil($total / $perPage),
        ];
    }

    public function search($keyword, $page = 1, $perPage = 12)
    {
        $offset = ($page - 1) * $perPage;
        $keyword = '%' . $keyword . '%';

        $sql = "SELECT p.*, MIN(bt.gia_ban) as gia_thap_nhat, MAX(bt.gia_ban) as gia_cao_nhat
                FROM {$this->table} p
                LEFT JOIN bien_the_san_pham bt ON p.id_san_pham = bt.san_pham_id
                WHERE p.ten_san_pham LIKE ? AND p.trang_thai = 'active'
                GROUP BY p.id_san_pham
                LIMIT $perPage OFFSET $offset";
        $items = $this->db->fetchAll($sql, [$keyword]);

        $countSql = "SELECT COUNT(*) as total FROM {$this->table} WHERE ten_san_pham LIKE ? AND trang_thai = 'active'";
        $total = $this->db->fetchOne($countSql, [$keyword])['total'];

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'totalPages' => ceil($total / $perPage),
        ];
    }

    public function getFeatured($limit = 8)
    {
        $sql = "SELECT p.*, MIN(bt.gia_ban) as gia_thap_nhat, MAX(bt.gia_ban) as gia_cao_nhat
                FROM {$this->table} p
                LEFT JOIN bien_the_san_pham bt ON p.id_san_pham = bt.san_pham_id
                WHERE p.trang_thai = 'active'
                GROUP BY p.id_san_pham
                ORDER BY p.id_san_pham DESC
                LIMIT $limit";
        return $this->db->fetchAll($sql);
    }

    public function getRelated($categoryId, $excludeId, $limit = 4)
    {
        $sql = "SELECT p.*, MIN(bt.gia_ban) as gia_thap_nhat, MAX(bt.gia_ban) as gia_cao_nhat
                FROM {$this->table} p
                LEFT JOIN bien_the_san_pham bt ON p.id_san_pham = bt.san_pham_id
                WHERE p.danh_muc_id = ? AND p.id_san_pham != ? AND p.trang_thai = 'active'
                GROUP BY p.id_san_pham
                LIMIT $limit";
        return $this->db->fetchAll($sql, [$categoryId, $excludeId]);
    }
}
