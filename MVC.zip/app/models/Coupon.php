<?php
class Coupon extends Model
{
    protected $table = 'khuyen_mai';

    public function getByCode($code)
    {
        $sql = "SELECT * FROM {$this->table} WHERE ma_khuyen_mai = ?";
        return $this->db->fetchOne($sql, [$code]);
    }

    public function getValid($code)
    {
        $now = date('Y-m-d H:i:s');
        $sql = "SELECT * FROM {$this->table}
                WHERE ma_khuyen_mai = ?
                AND ngay_bat_dau <= ?
                AND ngay_ket_thuc >= ?";
        return $this->db->fetchOne($sql, [$code, $now, $now]);
    }
}
