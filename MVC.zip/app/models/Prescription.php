<?php
class Prescription extends Model
{
    protected $table = 'yeu_cau_ke_toa';

    public function getWithUser($id)
    {
        $sql = "SELECT y.*, nd.ho_ten, nd.email, nd.so_dien_thoai
                FROM {$this->table} y
                LEFT JOIN nguoi_dung nd ON y.nguoi_dung_id = nd.id_nguoi_dung
                WHERE y.id_yeu_cau = ?";
        return $this->db->fetchOne($sql, [$id]);
    }

    public function getDetails($prescriptionId)
    {
        $sql = "SELECT ct.*, bt.ten_bien_the, bt.don_vi_tinh, bt.gia_ban, sp.ten_san_pham
                FROM chi_tiet_toa_ke_don ct
                JOIN bien_the_san_pham bt ON ct.bien_the_id = bt.id_bien_the
                JOIN san_pham sp ON bt.san_pham_id = sp.id_san_pham
                WHERE ct.yeu_cau_id = ?";
        return $this->db->fetchAll($sql, [$prescriptionId]);
    }

    public function getByUserId($userId)
    {
        $sql = "SELECT * FROM {$this->table} WHERE nguoi_dung_id = ? ORDER BY ngay_gui DESC";
        return $this->db->fetchAll($sql, [$userId]);
    }

    public function getPending()
    {
        $sql = "SELECT y.*, nd.ho_ten, nd.so_dien_thoai
                FROM {$this->table} y
                LEFT JOIN nguoi_dung nd ON y.nguoi_dung_id = nd.id_nguoi_dung
                WHERE y.trang_thai = 'pending'
                ORDER BY y.ngay_gui ASC";
        return $this->db->fetchAll($sql);
    }
}
