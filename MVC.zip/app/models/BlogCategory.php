<?php
class BlogCategory extends Model
{
    protected $table = 'danh_muc_tin_tuc';

    public function getWithPostCount()
    {
        $sql = "SELECT c.*, COUNT(t.id_tin_tuc) as so_luong_bai
                FROM {$this->table} c
                LEFT JOIN tin_tuc t ON c.id_danh_muc_tin = t.danh_muc_tin_id
                GROUP BY c.id_danh_muc_tin
                ORDER BY c.ten_danh_muc";
        return $this->db->fetchAll($sql);
    }
}
