<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'da1_nhom5');
define('DB_USER', 'root');
define('DB_PASS', '190507');
define('DB_CHARSET', 'utf8mb4');
