<?php
define('BASE_URL', 'http://localhost/DA1_Nhom5');
define('PATH_ROOT', dirname(dirname(__DIR__)) . DIRECTORY_SEPARATOR);
define('PATH_APP', PATH_ROOT . 'app' . DIRECTORY_SEPARATOR);
define('PATH_VIEWS', PATH_APP . 'views' . DIRECTORY_SEPARATOR);
define('PATH_PUBLIC', PATH_ROOT . 'public' . DIRECTORY_SEPARATOR);
define('PATH_UPLOADS', PATH_PUBLIC . 'uploads' . DIRECTORY_SEPARATOR);
define('SITE_NAME', 'Nhà Thuốc 5');
define('SITE_SLOGAN', 'Hệ thống nhà thuốc lớn số 1 VN');

define('ITEMS_PER_PAGE', 12);
define('ITEMS_PER_PAGE_ADMIN', 20);
