<?php
namespace Website;

class HomeController extends \Controller
{
    public function index()
    {
        $productModel = new \Product();
        $categoryModel = new \Category();
        $blogModel = new \Blog();

        $featuredProducts = $productModel->getFeatured(8);
        $categories = $categoryModel->getActiveWithProducts();
        $latestPosts = $blogModel->getLatest(3);

        $this->render('website/home', [
            'featuredProducts' => $featuredProducts,
            'categories' => $categories,
            'latestPosts' => $latestPosts,
            'pageTitle' => 'Trang chủ',
        ]);
    }

    public function about()
    {
        $this->render('website/about', [
            'pageTitle' => 'Giới thiệu',
        ]);
    }

    public function contact()
    {
        $this->render('website/contact', [
            'pageTitle' => 'Liên hệ',
        ]);
    }

    public function stores()
    {
        $this->render('website/stores', [
            'pageTitle' => 'Hệ thống nhà thuốc',
        ]);
    }
}
