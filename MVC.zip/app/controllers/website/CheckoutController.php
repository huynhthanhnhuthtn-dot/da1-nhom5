<?php
namespace Website;

class CheckoutController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireLogin();

        $cartModel = new \Cart();
        $cart = $cartModel->getByUserId(\Session::get('user_id'));

        if (!$cart) {
            \Session::setFlash('error', 'Giỏ hàng trống');
            $this->redirect(BASE_URL . '/gio-hang');
        }

        $items = $cartModel->getItems($cart['id_gio_hang']);
        $total = $cartModel->getTotal($cart['id_gio_hang']);

        $this->render('website/checkout', [
            'items' => $items,
            'total' => $total,
            'pageTitle' => 'Thanh toán',
        ]);
    }

    public function placeOrder()
    {
        \Session::init();
        \Session::requireLogin();

        $userId = \Session::get('user_id');
        $cartModel = new \Cart();
        $orderModel = new \Order();

        $cart = $cartModel->getByUserId($userId);
        if (!$cart) {
            $this->json(['success' => false, 'message' => 'Giỏ hàng trống']);
        }

        $items = $cartModel->getItems($cart['id_gio_hang']);
        $total = $cartModel->getTotal($cart['id_gio_hang']);

        if (empty($items)) {
            $this->json(['success' => false, 'message' => 'Giỏ hàng trống']);
        }

        $orderCode = $orderModel->generateOrderCode();
        $orderData = [
            'nguoi_dung_id' => $userId,
            'ma_don_hang' => $orderCode,
            'nguoi_nhan' => $this->postParam('nguoi_nhan'),
            'so_dien_thoai' => $this->postParam('so_dien_thoai'),
            'dia_chi_giao_hang' => $this->postParam('dia_chi_giao_hang'),
            'loai_don_hang' => 'over_the_counter',
            'trang_thai_don_hang' => 'pending',
            'tong_tien_hang' => $total,
            'phi_van_chuyen' => 0,
            'giam_gia' => 0,
            'thanh_tien' => $total,
            'ngay_dat' => date('Y-m-d H:i:s'),
        ];

        $orderId = $orderModel->createOrder($orderData);

        if ($orderId) {
            foreach ($items as $item) {
                $detailSql = "INSERT INTO chi_tiet_don_hang (don_hang_id, bien_the_id, so_luong, gia_ban)
                             VALUES (?, ?, ?, ?)";
                $orderModel->db->query($detailSql, [
                    $orderId, $item['bien_the_id'], $item['so_luong'], $item['gia_ban']
                ]);
            }

            $sql = "DELETE FROM chi_tiet_gio_hang WHERE gio_hang_id = ?";
            $orderModel->db->query($sql, [$cart['id_gio_hang']]);

            $this->json([
                'success' => true,
                'order_id' => $orderId,
                'redirect' => BASE_URL . '/don-hang-thanh-cong/' . $orderId,
            ]);
        } else {
            $this->json(['success' => false, 'message' => 'Đặt hàng thất bại']);
        }
    }

    public function success($id)
    {
        $orderModel = new \Order();
        $order = $orderModel->getWithDetails($id);
        $items = $orderModel->getItems($id);

        $this->render('website/order_success', [
            'order' => $order,
            'items' => $items,
            'pageTitle' => 'Đặt hàng thành công',
        ]);
    }
}
