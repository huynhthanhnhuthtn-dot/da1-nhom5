<?php
namespace Website;

class ProductController extends \Controller
{
    public function index()
    {
        $productModel = new \Product();
        $categoryModel = new \Category();
        $brandModel = new \Brand();

        $page = (int)($this->getParam('page', 1));
        $keyword = $this->getParam('keyword', '');
        $categoryId = $this->getParam('danh_muc', '');

        if ($keyword) {
            $result = $productModel->search($keyword, $page);
        } else {
            $result = $productModel->getFeatured(ITEMS_PER_PAGE);
            $result = [
                'items' => $productModel->getFeatured(ITEMS_PER_PAGE),
                'total' => $productModel->count(),
                'page' => $page,
                'totalPages' => ceil($productModel->count() / ITEMS_PER_PAGE),
            ];
        }

        $categories = $categoryModel->getActiveWithProducts();
        $brands = $brandModel->getAll();

        $this->render('website/product_list', [
            'products' => $result['items'],
            'total' => $result['total'],
            'page' => $result['page'],
            'totalPages' => $result['totalPages'],
            'categories' => $categories,
            'brands' => $brands,
            'keyword' => $keyword,
            'pageTitle' => 'Sản phẩm',
        ]);
    }

    public function detail($id)
    {
        $productModel = new \Product();
        $reviewModel = new \Review();

        $product = $productModel->getWithDetails($id);
        if (!$product) {
            $this->redirect(BASE_URL . '/san-pham');
        }
        $variants = $productModel->getVariants($product['id_san_pham']);
        $relatedProducts = $productModel->getRelated($product['danh_muc_id'], $product['id_san_pham']);
        $reviews = $reviewModel->getByProduct($product['id_san_pham']);
        $ratingStats = $reviewModel->getRatingStats($product['id_san_pham']);

        $product['danh_sach_hinh_nho'] = json_decode($product['danh_sach_hinh_nho'] ?? '[]', true);

        $this->render('website/product_detail', [
            'product' => $product,
            'variants' => $variants,
            'relatedProducts' => $relatedProducts,
            'reviews' => $reviews,
            'ratingStats' => $ratingStats,
            'pageTitle' => $product['ten_san_pham'],
        ]);
    }

    public function category($slug)
    {
        $categoryModel = new \Category();
        $productModel = new \Product();

        $category = null;
        $categories = $categoryModel->getAll();
        foreach ($categories as $cat) {
            if (\generateSlug($cat['ten_danh_muc']) === $slug) {
                $category = $cat;
                break;
            }
        }

        if (!$category) {
            $this->redirect(BASE_URL . '/san-pham');
        }

        $page = (int)($this->getParam('page', 1));
        $result = $productModel->getByCategory($category['id_danh_muc'], $page, ITEMS_PER_PAGE);

        $this->render('website/product_list', [
            'products' => $result['items'],
            'total' => $result['total'],
            'page' => $result['page'],
            'totalPages' => $result['totalPages'],
            'category' => $category,
            'categories' => $categoryModel->getActiveWithProducts(),
            'pageTitle' => $category['ten_danh_muc'],
        ]);
    }
}
