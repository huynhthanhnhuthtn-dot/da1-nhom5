<?php
namespace Website;

class BlogController extends \Controller
{
    public function index()
    {
        $blogModel = new \Blog();
        $categoryModel = new \BlogCategory();

        $page = (int)($this->getParam('page', 1));
        $categoryId = $this->getParam('danh_muc', '');

        if ($categoryId) {
            $result = $blogModel->getByCategory($categoryId, $page);
            $category = $categoryModel->getById($categoryId);
        } else {
            $result = $blogModel->getPublished($page);
            $category = null;
        }

        $categories = $categoryModel->getWithPostCount();

        $this->render('website/blog_list', [
            'posts' => $result['items'],
            'total' => $result['total'],
            'page' => $result['page'],
            'totalPages' => $result['totalPages'],
            'categories' => $categories,
            'selectedCategory' => $category,
            'pageTitle' => 'Tin tức',
        ]);
    }

    public function detail($slug)
    {
        $blogModel = new \Blog();
        $categoryModel = new \BlogCategory();

        $post = $blogModel->getBySlug($slug);
        if (!$post) {
            $this->redirect(BASE_URL . '/tin-tuc');
        }

        $blogModel->incrementViews($post['id_tin_tuc']);
        $categories = $categoryModel->getWithPostCount();
        $latestPosts = $blogModel->getLatest(5);

        $this->render('website/blog_detail', [
            'post' => $post,
            'categories' => $categories,
            'latestPosts' => $latestPosts,
            'pageTitle' => $post['tieu_de'],
        ]);
    }
}
