<?php
namespace Website;

class PrescriptionController extends \Controller
{
    public function index()
    {
        \Session::init();
        $this->render('website/prescription', ['pageTitle' => 'Gửi đơn thuốc']);
    }

    public function submit()
    {
        \Session::init();
        $prescriptionModel = new \Prescription();

        $data = [
            'nguoi_dung_id' => \Session::get('user_id'),
            'ho_ten_khach' => $this->postParam('ho_ten'),
            'so_dien_thoai' => $this->postParam('so_dien_thoai'),
            'mo_ta_trieu_chung' => $this->postParam('trieu_chung'),
            'trang_thai' => 'pending',
            'ngay_gui' => date('Y-m-d H:i:s'),
        ];

        if (isset($_FILES['anh_toa_thuoc']) && $_FILES['anh_toa_thuoc']['error'] === 0) {
            $uploadPath = uploadFile($_FILES['anh_toa_thuoc'], 'prescriptions');
            if ($uploadPath) {
                $data['anh_toa_thuoc'] = $uploadPath;
            }
        }

        $result = $prescriptionModel->create($data);

        if ($result) {
            \Session::setFlash('success', 'Gửi đơn thuốc thành công. Chúng tôi sẽ liên hệ bạn sớm!');
        } else {
            \Session::setFlash('error', 'Gửi đơn thuốc thất bại');
        }

        $this->redirect(BASE_URL . '/ke-toa');
    }
}
