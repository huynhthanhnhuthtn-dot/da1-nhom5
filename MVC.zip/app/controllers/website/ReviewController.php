<?php
namespace Website;

class ReviewController extends \Controller
{
    public function add()
    {
        \Session::init();
        \Session::requireLogin();

        $data = [
            'san_pham_id' => $this->postParam('san_pham_id'),
            'nguoi_dung_id' => \Session::get('user_id'),
            'so_sao' => (int)$this->postParam('so_sao', 5),
            'noi_dung' => $this->postParam('noi_dung', ''),
            'trang_thai' => 'active',
            'ngay_tao' => date('Y-m-d H:i:s'),
        ];

        $review = new \Review();
        $review->create($data);

        \Session::setFlash('success', 'Cảm ơn bạn đã đánh giá!');
        $this->redirect(BASE_URL . '/san-pham/' . $this->postParam('san_pham_id'));
    }
}
