<?php
namespace Website;

class WishlistController extends \Controller
{
    public function add()
    {
        \Session::init();
        if (!\Session::isLoggedIn()) {
            $this->json(['success' => false, 'message' => 'Vui lòng đăng nhập']);
        }

        $productId = $this->postParam('san_pham_id');
        $wishlist = new \Wishlist();
        $result = $wishlist->toggle(\Session::get('user_id'), $productId);

        $this->json(['success' => true, 'added' => $result]);
    }

    public function remove()
    {
        \Session::init();
        $productId = $this->postParam('san_pham_id');
        $wishlist = new \Wishlist();
        $item = $wishlist->check(\Session::get('user_id'), $productId);

        if ($item) {
            $wishlist->delete($item['id_yeu_thich']);
        }

        $this->json(['success' => true]);
    }
}
