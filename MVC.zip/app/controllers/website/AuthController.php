<?php
namespace Website;

class AuthController extends \Controller
{
    public function loginForm()
    {
        \Session::init();
        if (\Session::isLoggedIn()) {
            $this->redirect(BASE_URL);
        }
        $this->render('website/login', ['pageTitle' => 'Đăng nhập']);
    }

    public function login()
    {
        \Session::init();
        $username = $this->postParam('ten_user');
        $password = $this->postParam('mat_khau');

        $userModel = new \User();
        $user = $userModel->login($username, $password);

        if ($user) {
            \Session::set('user_id', $user['id_nguoi_dung']);
            \Session::set('user_name', $user['ho_ten']);
            \Session::set('user_role', $user['vai_tro']);
            \Session::setFlash('success', 'Đăng nhập thành công');
            $this->redirect(BASE_URL);
        } else {
            \Session::setFlash('error', 'Tên đăng nhập hoặc mật khẩu không đúng');
            $this->redirect(BASE_URL . '/dang-nhap');
        }
    }

    public function registerForm()
    {
        $this->render('website/register', ['pageTitle' => 'Đăng ký']);
    }

    public function register()
    {
        \Session::init();
        $data = [
            'ho_ten' => $this->postParam('ho_ten'),
            'email' => $this->postParam('email'),
            'so_dien_thoai' => $this->postParam('so_dien_thoai'),
            'ten_user' => $this->postParam('ten_user'),
            'mat_khau' => $this->postParam('mat_khau'),
        ];

        $userModel = new \User();
        $existingUser = $userModel->getByUsername($data['ten_user']);
        if ($existingUser) {
            \Session::setFlash('error', 'Tên đăng nhập đã tồn tại');
            $this->redirect(BASE_URL . '/dang-ky');
        }

        $existingEmail = $userModel->getByEmail($data['email']);
        if ($existingEmail) {
            \Session::setFlash('error', 'Email đã được sử dụng');
            $this->redirect(BASE_URL . '/dang-ky');
        }

        $userId = $userModel->register($data);
        if ($userId) {
            \Session::set('user_id', $userId);
            \Session::set('user_name', $data['ho_ten']);
            \Session::set('user_role', 'customer');
            \Session::setFlash('success', 'Đăng ký thành công');
            $this->redirect(BASE_URL);
        } else {
            \Session::setFlash('error', 'Đăng ký thất bại');
            $this->redirect(BASE_URL . '/dang-ky');
        }
    }

    public function logout()
    {
        \Session::init();
        \Session::destroy();
        $this->redirect(BASE_URL);
    }
}
