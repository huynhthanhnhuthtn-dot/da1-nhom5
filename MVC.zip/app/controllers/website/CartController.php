<?php
namespace Website;

class CartController extends \Controller
{
    public function index()
    {
        \Session::init();
        if (!\Session::isLoggedIn()) {
            \Session::setFlash('error', 'Vui lòng đăng nhập để xem giỏ hàng');
            $this->redirect(BASE_URL . '/dang-nhap');
        }

        $cartModel = new \Cart();
        $cart = $cartModel->getByUserId(\Session::get('user_id'));

        $items = [];
        $total = 0;
        if ($cart) {
            $items = $cartModel->getItems($cart['id_gio_hang']);
            $total = $cartModel->getTotal($cart['id_gio_hang']);
        }

        $this->render('website/cart', [
            'items' => $items,
            'total' => $total,
            'pageTitle' => 'Giỏ hàng',
        ]);
    }

    public function add()
    {
        \Session::init();
        if (!\Session::isLoggedIn()) {
            $this->json(['success' => false, 'message' => 'Vui lòng đăng nhập']);
        }

        $variantId = $this->postParam('bien_the_id');
        $quantity = (int)$this->postParam('so_luong', 1);

        if (!$variantId || $quantity < 1) {
            $this->json(['success' => false, 'message' => 'Dữ liệu không hợp lệ']);
        }

        $cartModel = new \Cart();
        $cart = $cartModel->getOrCreate(\Session::get('user_id'));
        $cartModel->addItem($cart['id_gio_hang'], $variantId, $quantity);

        $this->json(['success' => true, 'message' => 'Đã thêm vào giỏ hàng']);
    }

    public function update()
    {
        \Session::init();
        $itemId = $this->postParam('id');
        $quantity = (int)$this->postParam('so_luong', 1);

        $cartModel = new \Cart();
        if ($quantity < 1) {
            $cartModel->removeItem($itemId);
        } else {
            $cartModel->updateItem($itemId, $quantity);
        }

        $this->json(['success' => true]);
    }

    public function remove()
    {
        \Session::init();
        $itemId = $this->postParam('id');

        $cartModel = new \Cart();
        $cartModel->removeItem($itemId);

        $this->json(['success' => true]);
    }
}
