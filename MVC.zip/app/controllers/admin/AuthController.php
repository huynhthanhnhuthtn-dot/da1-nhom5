<?php
namespace Admin;

class AuthController extends \Controller
{
    public function loginForm()
    {
        \Session::init();
        if (\Session::isAdmin()) {
            $this->redirect(BASE_URL . '/admin');
        }
        $this->view('admin/login');
    }

    public function login()
    {
        \Session::init();
        $username = $this->postParam('ten_user');
        $password = $this->postParam('mat_khau');

        $userModel = new \User();
        $user = $userModel->login($username, $password);

        if ($user && $user['vai_tro'] === 'admin') {
            \Session::set('user_id', $user['id_nguoi_dung']);
            \Session::set('user_name', $user['ho_ten']);
            \Session::set('user_role', $user['vai_tro']);
            \Session::setFlash('success', 'Đăng nhập thành công');
            $this->redirect(BASE_URL . '/admin');
        } else {
            \Session::setFlash('error', 'Tài khoản hoặc mật khẩu không đúng');
            $this->redirect(BASE_URL . '/admin/dang-nhap');
        }
    }

    public function logout()
    {
        \Session::init();
        \Session::destroy();
        $this->redirect(BASE_URL . '/admin/dang-nhap');
    }
}
