<?php
namespace Admin;

class OrderController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireAdmin();

        $orderModel = new \Order();
        $page = (int)($this->getParam('page', 1));
        $result = $orderModel->paginate($page, ITEMS_PER_PAGE_ADMIN, '1=1', [], 'ngay_dat DESC');

        $this->render('admin/order_list', [
            'orders' => $result['items'],
            'total' => $result['total'],
            'page' => $result['page'],
            'totalPages' => $result['totalPages'],
            'pageTitle' => 'Quản lý đơn hàng',
        ], 'admin');
    }

    public function detail($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $orderModel = new \Order();
        $order = $orderModel->getWithDetails($id);
        $items = $orderModel->getItems($id);

        $this->render('admin/order_detail', [
            'order' => $order,
            'items' => $items,
            'pageTitle' => 'Chi tiết đơn hàng',
        ], 'admin');
    }

    public function updateStatus()
    {
        \Session::init();
        \Session::requireAdmin();

        $orderModel = new \Order();
        $orderModel->update(
            ['trang_thai_don_hang' => $this->postParam('trang_thai')],
            $this->postParam('id')
        );

        \Session::setFlash('success', 'Cập nhật trạng thái đơn hàng thành công');
        $this->redirect(BASE_URL . '/admin/don-hang/' . $this->postParam('id'));
    }
}
