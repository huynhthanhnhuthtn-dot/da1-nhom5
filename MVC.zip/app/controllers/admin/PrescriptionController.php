<?php
namespace Admin;

class PrescriptionController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireAdmin();

        $prescriptionModel = new \Prescription();
        $prescriptions = $prescriptionModel->getAll('ngay_gui DESC');

        $this->render('admin/prescription_list', [
            'prescriptions' => $prescriptions,
            'pageTitle' => 'Quản lý yêu cầu kê toa',
        ], 'admin');
    }

    public function detail($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $prescriptionModel = new \Prescription();
        $prescription = $prescriptionModel->getWithUser($id);
        $details = $prescriptionModel->getDetails($id);

        $this->render('admin/prescription_detail', [
            'prescription' => $prescription,
            'details' => $details,
            'pageTitle' => 'Chi tiết yêu cầu kê toa',
        ], 'admin');
    }

    public function updateStatus()
    {
        \Session::init();
        \Session::requireAdmin();

        $prescriptionModel = new \Prescription();
        $prescriptionModel->update(
            ['trang_thai' => $this->postParam('trang_thai')],
            $this->postParam('id')
        );

        \Session::setFlash('success', 'Cập nhật trạng thái thành công');
        $this->redirect(BASE_URL . '/admin/yeu-cau-ke-toa/' . $this->postParam('id'));
    }
}
