<?php
namespace Admin;

class CategoryController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireAdmin();

        $categoryModel = new \Category();
        $categories = $categoryModel->getWithProductCount();

        $this->render('admin/category_list', [
            'categories' => $categories,
            'pageTitle' => 'Quản lý danh mục',
        ], 'admin');
    }

    public function create()
    {
        \Session::init();
        \Session::requireAdmin();
        $this->view('admin/category_form', ['pageTitle' => 'Thêm danh mục']);
    }

    public function store()
    {
        \Session::init();
        \Session::requireAdmin();

        $categoryModel = new \Category();
        $categoryModel->create([
            'ten_danh_muc' => $this->postParam('ten_danh_muc'),
        ]);

        \Session::setFlash('success', 'Thêm danh mục thành công');
        $this->redirect(BASE_URL . '/admin/danh-muc');
    }

    public function edit($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $categoryModel = new \Category();
        $category = $categoryModel->getById($id);

        $this->view('admin/category_form', [
            'category' => $category,
            'pageTitle' => 'Sửa danh mục',
        ]);
    }

    public function update($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $categoryModel = new \Category();
        $categoryModel->update(
            ['ten_danh_muc' => $this->postParam('ten_danh_muc')],
            $id
        );

        \Session::setFlash('success', 'Cập nhật danh mục thành công');
        $this->redirect(BASE_URL . '/admin/danh-muc');
    }

    public function delete($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $categoryModel = new \Category();
        $categoryModel->delete($id);

        \Session::setFlash('success', 'Xóa danh mục thành công');
        $this->redirect(BASE_URL . '/admin/danh-muc');
    }
}
