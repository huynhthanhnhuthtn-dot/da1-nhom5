<?php
namespace Admin;

class BrandController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireAdmin();

        $brandModel = new \Brand();
        $brands = $brandModel->getWithProductCount();

        $this->render('admin/brand_list', [
            'brands' => $brands,
            'pageTitle' => 'Quản lý thương hiệu',
        ], 'admin');
    }

    public function create()
    {
        \Session::init();
        \Session::requireAdmin();
        $this->view('admin/brand_form', ['pageTitle' => 'Thêm thương hiệu']);
    }

    public function store()
    {
        \Session::init();
        \Session::requireAdmin();

        $brandModel = new \Brand();
        $brandModel->create([
            'ten_thuong_hieu' => $this->postParam('ten_thuong_hieu'),
        ]);

        \Session::setFlash('success', 'Thêm thương hiệu thành công');
        $this->redirect(BASE_URL . '/admin/thuong-hieu');
    }

    public function edit($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $brandModel = new \Brand();
        $brand = $brandModel->getById($id);

        $this->view('admin/brand_form', [
            'brand' => $brand,
            'pageTitle' => 'Sửa thương hiệu',
        ]);
    }

    public function update($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $brandModel = new \Brand();
        $brandModel->update(
            ['ten_thuong_hieu' => $this->postParam('ten_thuong_hieu')],
            $id
        );

        \Session::setFlash('success', 'Cập nhật thương hiệu thành công');
        $this->redirect(BASE_URL . '/admin/thuong-hieu');
    }

    public function delete($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $brandModel = new \Brand();
        $brandModel->delete($id);

        \Session::setFlash('success', 'Xóa thương hiệu thành công');
        $this->redirect(BASE_URL . '/admin/thuong-hieu');
    }
}
