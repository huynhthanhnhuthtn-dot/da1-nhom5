<?php
namespace Admin;

class BlogController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireAdmin();

        $blogModel = new \Blog();
        $page = (int)($this->getParam('page', 1));
        $result = $blogModel->paginate($page, ITEMS_PER_PAGE_ADMIN);

        foreach ($result['items'] as &$item) {
            $catModel = new \BlogCategory();
            $cat = $catModel->getById($item['danh_muc_tin_id']);
            $item['ten_danh_muc'] = $cat['ten_danh_muc'] ?? '';
        }

        $this->render('admin/blog_list', [
            'posts' => $result['items'],
            'total' => $result['total'],
            'page' => $result['page'],
            'totalPages' => $result['totalPages'],
            'pageTitle' => 'Quản lý tin tức',
        ], 'admin');
    }

    public function create()
    {
        \Session::init();
        \Session::requireAdmin();

        $catModel = new \BlogCategory();
        $categories = $catModel->getAll();

        $this->view('admin/blog_form', [
            'categories' => $categories,
            'post' => null,
            'pageTitle' => 'Thêm bài viết',
        ]);
    }

    public function store()
    {
        \Session::init();
        \Session::requireAdmin();

        $data = [
            'danh_muc_tin_id' => $this->postParam('danh_muc_tin_id'),
            'nguoi_viet_id' => \Session::get('user_id'),
            'tieu_de' => $this->postParam('tieu_de'),
            'slug' => generateSlug($this->postParam('tieu_de')),
            'tom_tat' => $this->postParam('tom_tat'),
            'noi_dung' => $this->postParam('noi_dung'),
            'trang_thai' => $this->postParam('trang_thai', 'active'),
            'ngay_tao' => date('Y-m-d H:i:s'),
            'ngay_cap_nhat' => date('Y-m-d H:i:s'),
        ];

        if (isset($_FILES['hinh_anh_dai_dien']) && $_FILES['hinh_anh_dai_dien']['error'] === 0) {
            $data['hinh_anh_dai_dien'] = uploadFile($_FILES['hinh_anh_dai_dien'], 'news');
        }

        $blogModel = new \Blog();
        $blogModel->create($data);

        \Session::setFlash('success', 'Thêm bài viết thành công');
        $this->redirect(BASE_URL . '/admin/tin-tuc');
    }

    public function edit($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $blogModel = new \Blog();
        $post = $blogModel->getById($id);
        $catModel = new \BlogCategory();
        $categories = $catModel->getAll();

        $this->view('admin/blog_form', [
            'post' => $post,
            'categories' => $categories,
            'pageTitle' => 'Sửa bài viết',
        ]);
    }

    public function update($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $data = [
            'danh_muc_tin_id' => $this->postParam('danh_muc_tin_id'),
            'tieu_de' => $this->postParam('tieu_de'),
            'slug' => generateSlug($this->postParam('tieu_de')),
            'tom_tat' => $this->postParam('tom_tat'),
            'noi_dung' => $this->postParam('noi_dung'),
            'trang_thai' => $this->postParam('trang_thai', 'active'),
            'ngay_cap_nhat' => date('Y-m-d H:i:s'),
        ];

        if (isset($_FILES['hinh_anh_dai_dien']) && $_FILES['hinh_anh_dai_dien']['error'] === 0) {
            $data['hinh_anh_dai_dien'] = uploadFile($_FILES['hinh_anh_dai_dien'], 'news');
        }

        $blogModel = new \Blog();
        $blogModel->update($data, $id);

        \Session::setFlash('success', 'Cập nhật bài viết thành công');
        $this->redirect(BASE_URL . '/admin/tin-tuc');
    }

    public function delete($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $blogModel = new \Blog();
        $blogModel->delete($id);

        \Session::setFlash('success', 'Xóa bài viết thành công');
        $this->redirect(BASE_URL . '/admin/tin-tuc');
    }
}
