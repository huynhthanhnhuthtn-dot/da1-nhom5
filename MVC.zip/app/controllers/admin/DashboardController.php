<?php
namespace Admin;

class DashboardController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireAdmin();

        $orderModel = new \Order();
        $userModel = new \User();
        $productModel = new \Product();

        $stats = $orderModel->getStats();
        $totalUsers = $userModel->count();
        $totalProducts = $productModel->count();
        $totalCustomers = $userModel->getCountByRole('customer');

        $recentOrders = $orderModel->getAll('ngay_dat DESC', 5);

        $this->render('admin/dashboard', [
            'stats' => $stats,
            'totalUsers' => $totalUsers,
            'totalProducts' => $totalProducts,
            'totalCustomers' => $totalCustomers,
            'recentOrders' => $recentOrders,
            'pageTitle' => 'Dashboard',
        ], 'admin');
    }
}
