<?php
namespace Admin;

class ProductController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireAdmin();

        $productModel = new \Product();
        $page = (int)($this->getParam('page', 1));
        $result = $productModel->paginate($page, ITEMS_PER_PAGE_ADMIN);

        foreach ($result['items'] as &$item) {
            $categoryModel = new \Category();
            $brandModel = new \Brand();
            $cat = $categoryModel->getById($item['danh_muc_id']);
            $brand = $brandModel->getById($item['thuong_hieu_id']);
            $item['ten_danh_muc'] = $cat['ten_danh_muc'] ?? '';
            $item['ten_thuong_hieu'] = $brand['ten_thuong_hieu'] ?? '';
        }

        $this->render('admin/product_list', [
            'products' => $result['items'],
            'total' => $result['total'],
            'page' => $result['page'],
            'totalPages' => $result['totalPages'],
            'pageTitle' => 'Quản lý sản phẩm',
        ], 'admin');
    }

    public function create()
    {
        \Session::init();
        \Session::requireAdmin();
        $categoryModel = new \Category();
        $brandModel = new \Brand();
        $categories = $categoryModel->getAll();
        $brands = $brandModel->getAll();

        $this->render('admin/product_form', [
            'categories' => $categories,
            'brands' => $brands,
            'product' => null,
            'pageTitle' => 'Thêm sản phẩm',
        ], 'admin');
    }

    public function store()
    {
        \Session::init();
        \Session::requireAdmin();

        $data = [
            'danh_muc_id' => $this->postParam('danh_muc_id'),
            'thuong_hieu_id' => $this->postParam('thuong_hieu_id'),
            'ten_san_pham' => $this->postParam('ten_san_pham'),
            'thuoc_ke_don' => $this->postParam('thuoc_ke_don', 'over_the_counter'),
            'mo_ta' => $this->postParam('mo_ta'),
            'trang_thai' => $this->postParam('trang_thai', 'active'),
        ];

        if (isset($_FILES['hinh_cover']) && $_FILES['hinh_cover']['error'] === 0) {
            $data['hinh_cover'] = uploadFile($_FILES['hinh_cover'], 'products');
        }

        $productModel = new \Product();
        $productId = $productModel->create($data);

        $variants = $this->postParam('bien_the', []);
        if (!empty($variants['ten'])) {
            foreach ($variants['ten'] as $i => $ten) {
                $variantData = [
                    'san_pham_id' => $productId,
                    'ten_bien_the' => $ten,
                    'don_vi_tinh' => $variants['don_vi_tinh'][$i] ?? '',
                    'gia_ban' => $variants['gia_ban'][$i] ?? 0,
                    'so_luong_ton' => $variants['so_luong_ton'][$i] ?? 0,
                ];
                $variantData['ma_sku'] = generateSKU($data['danh_muc_id'], $productId, $i + 1);
                $db = Database::getInstance();
                $db->insert('bien_the_san_pham', $variantData);
            }
        }

        \Session::setFlash('success', 'Thêm sản phẩm thành công');
        $this->redirect(BASE_URL . '/admin/san-pham');
    }

    public function edit($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $productModel = new \Product();
        $product = $productModel->getWithDetails($id);
        $variants = $productModel->getVariants($id);
        $categoryModel = new \Category();
        $brandModel = new \Brand();
        $categories = $categoryModel->getAll();
        $brands = $brandModel->getAll();

        $this->render('admin/product_form', [
            'product' => $product,
            'variants' => $variants,
            'categories' => $categories,
            'brands' => $brands,
            'pageTitle' => 'Sửa sản phẩm',
        ], 'admin');
    }

    public function update($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $data = [
            'danh_muc_id' => $this->postParam('danh_muc_id'),
            'thuong_hieu_id' => $this->postParam('thuong_hieu_id'),
            'ten_san_pham' => $this->postParam('ten_san_pham'),
            'thuoc_ke_don' => $this->postParam('thuoc_ke_don', 'over_the_counter'),
            'mo_ta' => $this->postParam('mo_ta'),
            'trang_thai' => $this->postParam('trang_thai', 'active'),
        ];

        if (isset($_FILES['hinh_cover']) && $_FILES['hinh_cover']['error'] === 0) {
            $data['hinh_cover'] = uploadFile($_FILES['hinh_cover'], 'products');
        }

        $productModel = new \Product();
        $productModel->update($data, $id);

        \Session::setFlash('success', 'Cập nhật sản phẩm thành công');
        $this->redirect(BASE_URL . '/admin/san-pham');
    }

    public function delete($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $productModel = new \Product();
        $productModel->delete($id);

        \Session::setFlash('success', 'Xóa sản phẩm thành công');
        $this->redirect(BASE_URL . '/admin/san-pham');
    }
}
