<?php
namespace Admin;

class BlogCategoryController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireAdmin();

        $catModel = new \BlogCategory();
        $categories = $catModel->getWithPostCount();

        $this->render('admin/blog_category_list', [
            'categories' => $categories,
            'pageTitle' => 'Quản lý danh mục tin',
        ], 'admin');
    }

    public function store()
    {
        \Session::init();
        \Session::requireAdmin();

        $catModel = new \BlogCategory();
        $catModel->create([
            'ten_danh_muc' => $this->postParam('ten_danh_muc'),
            'mo_ta' => $this->postParam('mo_ta'),
        ]);

        \Session::setFlash('success', 'Thêm danh mục tin thành công');
        $this->redirect(BASE_URL . '/admin/danh-muc-tin');
    }

    public function update()
    {
        \Session::init();
        \Session::requireAdmin();

        $catModel = new \BlogCategory();
        $catModel->update(
            ['ten_danh_muc' => $this->postParam('ten_danh_muc')],
            $this->postParam('id')
        );

        \Session::setFlash('success', 'Cập nhật danh mục tin thành công');
        $this->redirect(BASE_URL . '/admin/danh-muc-tin');
    }

    public function delete($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $catModel = new \BlogCategory();
        $catModel->delete($id);

        \Session::setFlash('success', 'Xóa danh mục tin thành công');
        $this->redirect(BASE_URL . '/admin/danh-muc-tin');
    }
}
