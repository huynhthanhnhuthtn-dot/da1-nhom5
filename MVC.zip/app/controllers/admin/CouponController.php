<?php
namespace Admin;

class CouponController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireAdmin();

        $couponModel = new \Coupon();
        $coupons = $couponModel->getAll();

        $this->render('admin/coupon_list', [
            'coupons' => $coupons,
            'pageTitle' => 'Quản lý khuyến mãi',
        ], 'admin');
    }

    public function create()
    {
        \Session::init();
        \Session::requireAdmin();
        $this->view('admin/coupon_form', ['pageTitle' => 'Thêm khuyến mãi']);
    }

    public function store()
    {
        \Session::init();
        \Session::requireAdmin();

        $couponModel = new \Coupon();
        $couponModel->create([
            'ten_khuyen_mai' => $this->postParam('ten_khuyen_mai'),
            'ma_khuyen_mai' => $this->postParam('ma_khuyen_mai'),
            'gia_tri_giam' => $this->postParam('gia_tri_giam'),
            'loai_giam_gia' => $this->postParam('loai_giam_gia'),
            'ngay_bat_dau' => $this->postParam('ngay_bat_dau'),
            'ngay_ket_thuc' => $this->postParam('ngay_ket_thuc'),
        ]);

        \Session::setFlash('success', 'Thêm khuyến mãi thành công');
        $this->redirect(BASE_URL . '/admin/khuyen-mai');
    }

    public function edit($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $couponModel = new \Coupon();
        $coupon = $couponModel->getById($id);

        $this->view('admin/coupon_form', [
            'coupon' => $coupon,
            'pageTitle' => 'Sửa khuyến mãi',
        ]);
    }

    public function update($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $couponModel = new \Coupon();
        $couponModel->update([
            'ten_khuyen_mai' => $this->postParam('ten_khuyen_mai'),
            'ma_khuyen_mai' => $this->postParam('ma_khuyen_mai'),
            'gia_tri_giam' => $this->postParam('gia_tri_giam'),
            'loai_giam_gia' => $this->postParam('loai_giam_gia'),
            'ngay_bat_dau' => $this->postParam('ngay_bat_dau'),
            'ngay_ket_thuc' => $this->postParam('ngay_ket_thuc'),
        ], $id);

        \Session::setFlash('success', 'Cập nhật khuyến mãi thành công');
        $this->redirect(BASE_URL . '/admin/khuyen-mai');
    }

    public function delete($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $couponModel = new \Coupon();
        $couponModel->delete($id);

        \Session::setFlash('success', 'Xóa khuyến mãi thành công');
        $this->redirect(BASE_URL . '/admin/khuyen-mai');
    }
}
