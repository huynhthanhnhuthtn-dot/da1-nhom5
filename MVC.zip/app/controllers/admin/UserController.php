<?php
namespace Admin;

class UserController extends \Controller
{
    public function index()
    {
        \Session::init();
        \Session::requireAdmin();

        $userModel = new \User();
        $page = (int)($this->getParam('page', 1));
        $result = $userModel->paginate($page, ITEMS_PER_PAGE_ADMIN);

        $this->render('admin/user_list', [
            'users' => $result['items'],
            'total' => $result['total'],
            'page' => $result['page'],
            'totalPages' => $result['totalPages'],
            'pageTitle' => 'Quản lý người dùng',
        ], 'admin');
    }

    public function edit($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $userModel = new \User();
        $user = $userModel->getById($id);

        $this->view('admin/user_form', [
            'user' => $user,
            'pageTitle' => 'Sửa người dùng',
        ]);
    }

    public function update($id)
    {
        \Session::init();
        \Session::requireAdmin();

        $data = [
            'ho_ten' => $this->postParam('ho_ten'),
            'email' => $this->postParam('email'),
            'so_dien_thoai' => $this->postParam('so_dien_thoai'),
            'vai_tro' => $this->postParam('vai_tro'),
            'trang_thai' => $this->postParam('trang_thai'),
        ];

        $password = $this->postParam('mat_khau');
        if (!empty($password)) {
            $data['mat_khau'] = password_hash($password, PASSWORD_DEFAULT);
        }

        $userModel = new \User();
        $userModel->update($data, $id);

        \Session::setFlash('success', 'Cập nhật người dùng thành công');
        $this->redirect(BASE_URL . '/admin/nguoi-dung');
    }
}
