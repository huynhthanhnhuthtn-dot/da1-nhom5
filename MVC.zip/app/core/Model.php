<?php
class Model
{
    protected $db;
    protected $table;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function getAll($orderBy = null, $limit = null, $offset = null)
    {
        $sql = "SELECT * FROM {$this->table}";
        if ($orderBy) {
            $sql .= " ORDER BY $orderBy";
        }
        if ($limit) {
            $sql .= " LIMIT $limit";
        }
        if ($offset) {
            $sql .= " OFFSET $offset";
        }
        return $this->db->fetchAll($sql);
    }

    public function getById($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE id_{$this->table} = ?";
        return $this->db->fetchOne($sql, [$id]);
    }

    public function create($data)
    {
        return $this->db->insert($this->table, $data);
    }

    public function update($data, $id)
    {
        $condition = ["id_{$this->table}" => $id];
        return $this->db->update($this->table, $data, $condition);
    }

    public function delete($id)
    {
        $condition = ["id_{$this->table}" => $id];
        return $this->db->delete($this->table, $condition);
    }

    public function count()
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table}";
        $result = $this->db->fetchOne($sql);
        return $result['total'];
    }

    public function paginate($page = 1, $perPage = 10, $where = '', $params = [], $orderBy = '')
    {
        $offset = ($page - 1) * $perPage;
        $whereClause = $where ? "WHERE $where" : '';
        $orderClause = $orderBy ? "ORDER BY $orderBy" : '';

        $countSql = "SELECT COUNT(*) as total FROM {$this->table} $whereClause";
        $countResult = $this->db->fetchOne($countSql, $params);
        $total = $countResult['total'];

        $sql = "SELECT * FROM {$this->table} $whereClause $orderClause LIMIT $perPage OFFSET $offset";
        $items = $this->db->fetchAll($sql, $params);

        $totalPages = ceil($total / $perPage);

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => $totalPages,
        ];
    }
}
