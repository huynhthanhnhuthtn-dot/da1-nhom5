<?php
class Database
{
    private static $instance = null;
    private $pdo;

    private function __construct()
    {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die('Connection failed: ' . $e->getMessage());
        }
    }

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection()
    {
        return $this->pdo;
    }

    public function query($sql, $params = [])
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function fetchAll($sql, $params = [])
    {
        return $this->query($sql, $params)->fetchAll();
    }

    public function fetchOne($sql, $params = [])
    {
        return $this->query($sql, $params)->fetch();
    }

    public function insert($table, $data)
    {
        $columns = implode(', ', array_keys($data));
        $values = ':' . implode(', :', array_keys($data));
        $sql = "INSERT INTO $table ($columns) VALUES ($values)";
        $this->query($sql, $data);
        return $this->pdo->lastInsertId();
    }

    public function update($table, $data, $condition)
    {
        $set = '';
        foreach ($data as $col => $val) {
            $set .= "$col = :$col, ";
        }
        $set = rtrim($set, ', ');

        $where = '';
        $params = array_merge($data, []);
        foreach ($condition as $col => $val) {
            $where .= "$col = :_cond_$col AND ";
            $params["_cond_$col"] = $val;
        }
        $where = rtrim($where, ' AND ');

        $sql = "UPDATE $table SET $set WHERE $where";
        return $this->query($sql, $params)->rowCount();
    }

    public function delete($table, $condition)
    {
        $where = '';
        $params = [];
        foreach ($condition as $col => $val) {
            $where .= "$col = :$col AND ";
            $params[$col] = $val;
        }
        $where = rtrim($where, ' AND ');
        $sql = "DELETE FROM $table WHERE $where";
        return $this->query($sql, $params)->rowCount();
    }
}
