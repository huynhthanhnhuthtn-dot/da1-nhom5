<?php
class Router
{
    private $routes = [];

    public function get($uri, $handler)
    {
        $this->routes['GET'][] = ['uri' => $uri, 'handler' => $handler];
    }

    public function post($uri, $handler)
    {
        $this->routes['POST'][] = ['uri' => $uri, 'handler' => $handler];
    }

    public function dispatch($uri, $method)
    {
        $uri = parse_url($uri, PHP_URL_PATH);
        $uri = rtrim($uri, '/');
        if ($uri === '') {
            $uri = '/';
        }

        if (!isset($this->routes[$method])) {
            $this->notFound();
            return;
        }

        foreach ($this->routes[$method] as $route) {
            $pattern = $this->convertToRegex($route['uri']);
            if (preg_match($pattern, $uri, $matches)) {
                array_shift($matches);
                $handler = $route['handler'];
                $controllerName = $handler[0];
                $actionName = $handler[1];

                if (class_exists($controllerName)) {
                    $controller = new $controllerName();
                    if (method_exists($controller, $actionName)) {
                        call_user_func_array([$controller, $actionName], $matches);
                        return;
                    }
                }
            }
        }

        $this->notFound();
    }

    private function convertToRegex($uri)
    {
        $pattern = preg_replace('/\{([a-zA-Z_]+)\}/', '(?P<$1>[^/]+)', $uri);
        return '#^' . $pattern . '$#';
    }

    private function notFound()
    {
        http_response_code(404);
        echo '404 - Not Found';
    }
}
