<?php
class Controller
{
    protected function view($path, $data = [])
    {
        extract($data);
        $file = PATH_VIEWS . $path . '.php';
        if (file_exists($file)) {
            require_once $file;
        } else {
            die("View not found: $path");
        }
    }

    protected function render($path, $data = [], $layout = 'website')
    {
        extract($data);
        $contentPath = PATH_VIEWS . $path . '.php';

        if (!file_exists($contentPath)) {
            die("View not found: $path");
        }

        ob_start();
        require $contentPath;
        $content = ob_get_clean();

        $layoutPath = PATH_VIEWS . 'layouts' . DIRECTORY_SEPARATOR . $layout . '_layout.php';
        if (file_exists($layoutPath)) {
            require $layoutPath;
        } else {
            echo $content;
        }
    }

    protected function json($data, $statusCode = 200)
    {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    protected function redirect($url)
    {
        header("Location: $url");
        exit;
    }

    protected function isPost()
    {
        return $_SERVER['REQUEST_METHOD'] === 'POST';
    }

    protected function getParam($key, $default = null)
    {
        return $_GET[$key] ?? $default;
    }

    protected function postParam($key, $default = null)
    {
        return $_POST[$key] ?? $default;
    }
}
