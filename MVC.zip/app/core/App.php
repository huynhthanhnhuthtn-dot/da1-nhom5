<?php
class App
{
    private $router;

    public function __construct()
    {
        $this->router = new Router();
        $this->registerRoutes();
    }

    private function registerRoutes()
    {
        $router = $this->router;
        require_once PATH_APP . 'routes' . DIRECTORY_SEPARATOR . 'web.php';
        require_once PATH_APP . 'routes' . DIRECTORY_SEPARATOR . 'admin.php';
    }

    public function run()
    {
        $method = $_SERVER['REQUEST_METHOD'];

        $uri = $_GET['url'] ?? '/';
        $uri = '/' . trim($uri, '/');

        $this->router->dispatch($uri, $method);
    }
}
