CREATE TABLE `nguoi_dung` (
  `id_nguoi_dung` int PRIMARY KEY AUTO_INCREMENT,
  `ho_ten` varchar(255),
  `email` varchar(255),
  `so_dien_thoai` varchar(20),
  `ten_user` varchar(100),
  `mat_khau` varchar(255),
  `trang_thai` varchar(50),
  `vai_tro` varchar(50)
);

CREATE TABLE `danh_muc_san_pham` (
  `id_danh_muc` int PRIMARY KEY AUTO_INCREMENT,
  `ten_danh_muc` varchar(255)
);

CREATE TABLE `thuong_hieu` (
  `id_thuong_hieu` int PRIMARY KEY AUTO_INCREMENT,
  `ten_thuong_hieu` varchar(255)
);

CREATE TABLE `san_pham` (
  `id_san_pham` int PRIMARY KEY AUTO_INCREMENT,
  `danh_muc_id` int,
  `thuong_hieu_id` int,
  `ten_san_pham` varchar(255),
  `hinh_cover` varchar(255),
  `danh_sach_hinh_nho` json,
  `thuoc_ke_don` varchar(50),
  `mo_ta` text,
  `trang_thai` varchar(50)
);

CREATE TABLE `bien_the_san_pham` (
  `id_bien_the` int PRIMARY KEY AUTO_INCREMENT,
  `san_pham_id` int,
  `ten_bien_the` varchar(255),
  `don_vi_tinh` varchar(50),
  `gia_ban` decimal(15,2),
  `so_luong_ton` int,
  `ma_sku` varchar(100),
  `hinh_anh_bien_the` varchar(255)
);

CREATE TABLE `gio_hang` (
  `id_gio_hang` int PRIMARY KEY AUTO_INCREMENT,
  `nguoi_dung_id` int,
  `ngay_tao` datetime,
  `ngay_cap_nhat` datetime
);

CREATE TABLE `chi_tiet_gio_hang` (
  `id_chi_tiet_gio_hang` int PRIMARY KEY AUTO_INCREMENT,
  `gio_hang_id` int,
  `bien_the_id` int,
  `so_luong` int
);

CREATE TABLE `yeu_cau_ke_toa` (
  `id_yeu_cau` int PRIMARY KEY AUTO_INCREMENT,
  `nguoi_dung_id` int,
  `nhan_vien_tu_van_id` int,
  `ho_ten_khach` varchar(255),
  `so_dien_thoai` varchar(20),
  `anh_toa_thuoc` varchar(255),
  `mo_ta_trieu_chung` text,
  `trang_thai` varchar(50),
  `ngay_gui` datetime
);

CREATE TABLE `chi_tiet_toa_ke_don` (
  `id_chi_tiet_toa` int PRIMARY KEY AUTO_INCREMENT,
  `yeu_cau_id` int,
  `bien_the_id` int,
  `so_luong` int,
  `huong_dan_su_dung` text
);

CREATE TABLE `khuyen_mai` (
  `id_khuyen_mai` int PRIMARY KEY AUTO_INCREMENT,
  `ten_khuyen_mai` varchar(255),
  `ma_khuyen_mai` varchar(50),
  `gia_tri_giam` decimal(15,2),
  `loai_giam_gia` varchar(50),
  `ngay_bat_dau` datetime,
  `ngay_ket_thuc` datetime
);

CREATE TABLE `don_hang` (
  `id_don_hang` int PRIMARY KEY AUTO_INCREMENT,
  `nguoi_dung_id` int,
  `yeu_cau_id` int,
  `ma_don_hang` varchar(100),
  `nguoi_nhan` varchar(255),
  `so_dien_thoai` varchar(20),
  `dia_chi_giao_hang` varchar(255),
  `loai_don_hang` varchar(50),
  `trang_thai_don_hang` varchar(50),
  `tong_tien_hang` decimal(15,2),
  `phi_van_chuyen` decimal(15,2),
  `giam_gia` decimal(15,2),
  `thanh_tien` decimal(15,2),
  `ngay_dat` datetime
);

CREATE TABLE `chi_tiet_don_hang` (
  `id_chi_tiet_don_hang` int PRIMARY KEY AUTO_INCREMENT,
  `don_hang_id` int,
  `bien_the_id` int,
  `so_luong` int,
  `gia_ban` decimal(15,2)
);

CREATE TABLE `don_hang_khuyen_mai` (
  `id_dh_km` int PRIMARY KEY AUTO_INCREMENT,
  `don_hang_id` int,
  `khuyen_mai_id` int,
  `so_tien_giam` decimal(15,2)
);

CREATE TABLE `phuong_thuc_thanh_toan` (
  `id_phuong_thuc` int PRIMARY KEY AUTO_INCREMENT,
  `ten_phuong_thuc` varchar(100)
);

CREATE TABLE `thanh_toan` (
  `id_thanh_toan` int PRIMARY KEY AUTO_INCREMENT,
  `don_hang_id` int,
  `phuong_thuc_id` int,
  `ma_giao_dich` varchar(100),
  `so_tien` decimal(15,2),
  `trang_thai` varchar(50),
  `thoi_gian_thanh_toan` datetime
);

CREATE TABLE `danh_muc_tin_tuc` (
  `id_danh_muc_tin` int PRIMARY KEY AUTO_INCREMENT,
  `ten_danh_muc` varchar(255),
  `mo_ta` text
);

CREATE TABLE `tin_tuc` (
  `id_tin_tuc` int PRIMARY KEY AUTO_INCREMENT,
  `danh_muc_tin_id` int,
  `nguoi_viet_id` int,
  `tieu_de` varchar(255),
  `slug` varchar(255),
  `hinh_anh_dai_dien` varchar(255),
  `tom_tat` text,
  `noi_dung` longtext,
  `luot_xem` int DEFAULT 0,
  `trang_thai` varchar(50),
  `ngay_tao` datetime,
  `ngay_cap_nhat` datetime
);

CREATE TABLE `danh_gia_binh_luan_san_pham` (
  `id_tu_ong` int PRIMARY KEY AUTO_INCREMENT,
  `san_pham_id` int,
  `nguoi_dung_id` int,
  `parent_id` int,
  `so_sao` int,
  `noi_dung` text,
  `trang_thai` varchar(50),
  `ngay_tao` datetime
);

CREATE TABLE `san_pham_yeu_thich` (
  `id_yeu_thich` int PRIMARY KEY AUTO_INCREMENT,
  `nguoi_dung_id` int,
  `san_pham_id` int,
  `ngay_them` datetime
);

ALTER TABLE `san_pham` ADD FOREIGN KEY (`danh_muc_id`) REFERENCES `danh_muc_san_pham` (`id_danh_muc`);

ALTER TABLE `san_pham` ADD FOREIGN KEY (`thuong_hieu_id`) REFERENCES `thuong_hieu` (`id_thuong_hieu`);

ALTER TABLE `bien_the_san_pham` ADD FOREIGN KEY (`san_pham_id`) REFERENCES `san_pham` (`id_san_pham`);

ALTER TABLE `gio_hang` ADD FOREIGN KEY (`nguoi_dung_id`) REFERENCES `nguoi_dung` (`id_nguoi_dung`);

ALTER TABLE `chi_tiet_gio_hang` ADD FOREIGN KEY (`gio_hang_id`) REFERENCES `gio_hang` (`id_gio_hang`);

ALTER TABLE `chi_tiet_gio_hang` ADD FOREIGN KEY (`bien_the_id`) REFERENCES `bien_the_san_pham` (`id_bien_the`);

ALTER TABLE `yeu_cau_ke_toa` ADD FOREIGN KEY (`nguoi_dung_id`) REFERENCES `nguoi_dung` (`id_nguoi_dung`);

ALTER TABLE `yeu_cau_ke_toa` ADD FOREIGN KEY (`nhan_vien_tu_van_id`) REFERENCES `nguoi_dung` (`id_nguoi_dung`);

ALTER TABLE `chi_tiet_toa_ke_don` ADD FOREIGN KEY (`yeu_cau_id`) REFERENCES `yeu_cau_ke_toa` (`id_yeu_cau`);

ALTER TABLE `chi_tiet_toa_ke_don` ADD FOREIGN KEY (`bien_the_id`) REFERENCES `bien_the_san_pham` (`id_bien_the`);

ALTER TABLE `don_hang` ADD FOREIGN KEY (`nguoi_dung_id`) REFERENCES `nguoi_dung` (`id_nguoi_dung`);

ALTER TABLE `don_hang` ADD FOREIGN KEY (`yeu_cau_id`) REFERENCES `yeu_cau_ke_toa` (`id_yeu_cau`);

ALTER TABLE `chi_tiet_don_hang` ADD FOREIGN KEY (`don_hang_id`) REFERENCES `don_hang` (`id_don_hang`);

ALTER TABLE `chi_tiet_don_hang` ADD FOREIGN KEY (`bien_the_id`) REFERENCES `bien_the_san_pham` (`id_bien_the`);

ALTER TABLE `don_hang_khuyen_mai` ADD FOREIGN KEY (`don_hang_id`) REFERENCES `don_hang` (`id_don_hang`);

ALTER TABLE `don_hang_khuyen_mai` ADD FOREIGN KEY (`khuyen_mai_id`) REFERENCES `khuyen_mai` (`id_khuyen_mai`);

ALTER TABLE `thanh_toan` ADD FOREIGN KEY (`don_hang_id`) REFERENCES `don_hang` (`id_don_hang`);

ALTER TABLE `thanh_toan` ADD FOREIGN KEY (`phuong_thuc_id`) REFERENCES `phuong_thuc_thanh_toan` (`id_phuong_thuc`);

ALTER TABLE `tin_tuc` ADD FOREIGN KEY (`danh_muc_tin_id`) REFERENCES `danh_muc_tin_tuc` (`id_danh_muc_tin`);

ALTER TABLE `tin_tuc` ADD FOREIGN KEY (`nguoi_viet_id`) REFERENCES `nguoi_dung` (`id_nguoi_dung`);

ALTER TABLE `danh_gia_binh_luan_san_pham` ADD FOREIGN KEY (`san_pham_id`) REFERENCES `san_pham` (`id_san_pham`);

ALTER TABLE `danh_gia_binh_luan_san_pham` ADD FOREIGN KEY (`nguoi_dung_id`) REFERENCES `nguoi_dung` (`id_nguoi_dung`);

ALTER TABLE `danh_gia_binh_luan_san_pham` ADD FOREIGN KEY (`parent_id`) REFERENCES `danh_gia_binh_luan_san_pham` (`id_tu_ong`);

ALTER TABLE `san_pham_yeu_thich` ADD FOREIGN KEY (`nguoi_dung_id`) REFERENCES `nguoi_dung` (`id_nguoi_dung`);

ALTER TABLE `san_pham_yeu_thich` ADD FOREIGN KEY (`san_pham_id`) REFERENCES `san_pham` (`id_san_pham`);
