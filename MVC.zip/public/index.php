<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../app/config/database.php';
require_once __DIR__ . '/../app/config/config.php';
require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/core/Router.php';
require_once __DIR__ . '/../app/core/Controller.php';
require_once __DIR__ . '/../app/core/Model.php';
require_once __DIR__ . '/../app/core/App.php';
require_once __DIR__ . '/../app/helpers/Session.php';
require_once __DIR__ . '/../app/helpers/functions.php';

Session::init();

require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Category.php';
require_once __DIR__ . '/../app/models/Brand.php';
require_once __DIR__ . '/../app/models/Product.php';
require_once __DIR__ . '/../app/models/Cart.php';
require_once __DIR__ . '/../app/models/Order.php';
require_once __DIR__ . '/../app/models/Blog.php';
require_once __DIR__ . '/../app/models/BlogCategory.php';
require_once __DIR__ . '/../app/models/Prescription.php';
require_once __DIR__ . '/../app/models/Coupon.php';
require_once __DIR__ . '/../app/models/Review.php';
require_once __DIR__ . '/../app/models/Wishlist.php';

function loadController($prefix, $name) {
    $file = __DIR__ . '/../app/controllers/' . $prefix . '/' . $name . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
}

$websiteControllers = ['HomeController', 'AuthController', 'ProductController', 'CartController',
    'CheckoutController', 'BlogController', 'PrescriptionController', 'WishlistController', 'ReviewController'];
foreach ($websiteControllers as $c) {
    loadController('website', $c);
}

$adminControllers = ['AuthController', 'DashboardController', 'ProductController', 'CategoryController',
    'BrandController', 'OrderController', 'UserController', 'BlogController', 'CouponController',
    'PrescriptionController', 'BlogCategoryController'];
foreach ($adminControllers as $c) {
    loadController('admin', $c);
}

$app = new App();
$app->run();
