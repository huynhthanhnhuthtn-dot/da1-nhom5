$(document).ready(function() {
    $('[data-bs-toggle="tooltip"]').tooltip();
    $('[data-bs-toggle="popover"]').popover();

    $('.table-responsive').on('click', '.btn-delete', function() {
        return confirm('Xóa mục này?');
    });
});
