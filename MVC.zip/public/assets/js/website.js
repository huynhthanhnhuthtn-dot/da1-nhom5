function formatPrice(price) {
    return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') + '₫';
}

function addToCart(variantId, quantity) {
    $.post(BASE_URL + '/gio-hang/them', {
        bien_the_id: variantId,
        so_luong: quantity
    }, function(res) {
        if (res.success) {
            alert('Đã thêm vào giỏ hàng!');
            updateCartCount();
        } else {
            alert(res.message || 'Có lỗi xảy ra');
        }
    });
}

function updateCartCount() {
    $.get(BASE_URL + '/gio-hang', function() {});
}

$(document).ready(function() {
    $('[data-bs-toggle="tooltip"]').tooltip();
});
